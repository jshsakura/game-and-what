﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "CJ 엘리펀트 퓨지티브"
    TargetPattern = "CJ Elephant Fugitive"
    BasePattern = @(
        "CJ.*Elephant.*Fugitive",
        "Elephant.*Fugitive.*CJ",
        "Fugitive.*CJ.*Elephant"
    )
},
@{
    Name = "F1 - 월드 챔피언십 에디션"
    TargetPattern = "F1 - World Championship Edition"
    BasePattern = @(
        "F1.*World.*Championship.*Edition",
        "World.*Championship.*F1",
        "Championship.*Edition.*F1"
    )
},
@{
    Name = "F1 - 포뮬러 원"
    TargetPattern = "Formula One"
    BasePattern = @(
        "Formula.*One",
        "One.*Formula",
        "F1.*Formula.*One"
    )
},

@{
    Name = "F-15 스트라이크 이글"
    TargetPattern = "F-15 Strike Eagle"
    BasePattern = @(
        "F.*15.*Strike.*Eagle",
        "Strike.*Eagle.*F.*15",
        "Eagle.*F.*15.*Strike"
    )
},

@{
    Name = "GG 시노비 II - 침묵의 분노"
    TargetPattern = "Shinobi II - The Silent Fury"
    BasePattern = @(
        "Shinobi.*II.*Silent.*Fury",
        "Silent.*Fury.*Shinobi.*II",
        "Shinobi.*2",
        "Shinobi.*II",
        "Fury.*Shinobi.*II.*Silent"
    )
},

@{
    Name = "GG 시노비"
    TargetPattern = "Shinobi"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III|silent|fury)).*Shinobi",
        "^(?!.*(?:2|3|II|III|silent|fury)).*GG.*Shinobi",
        "^(?!.*(?:2|3|II|III|silent|fury)).*Shinobi.*GG"
    )
},

@{
    Name = "SD 건담 - 위너스 히스토리"
    TargetPattern = "SD Gundam - Winner's History"
    BasePattern = @(
        "SD.*Gundam.*Winner.*History",
        "Winner.*History.*SD.*Gundam",
        "Gundam.*Winner.*SD.*History"
    )
},
@{
    Name = "VR 트루퍼스"
    TargetPattern = "VR Troopers"
    BasePattern = @(
        "VR.*Troopers",
        "Troopers.*VR",
        "VR.*Trooper"
    )
},
@{
    Name = "WWF 로우"
    TargetPattern = "WWF Raw"
    BasePattern = @(
        "WWF.*Raw",
        "Raw.*WWF",
        "WWF.*Raw"
    )
},
@{
    Name = "가와사키 슈퍼바이크 챌린지"
    TargetPattern = "Kawasaki Superbike Challenge"
    BasePattern = @(
        "Kawasaki.*Superbike.*Challenge",
        "Superbike.*Challenge.*Kawasaki",
        "Challenge.*Kawasaki.*Superbike"
    )
},
@{
    Name = "가필드 - 현장에서 잡히다"
    TargetPattern = "Garfield - Caught in the Act"
    BasePattern = @(
        "Garfield.*Caught.*Act",
        "Caught.*Act.*Garfield",
        "Act.*Garfield.*Caught"
    )
},
@{
    Name = "갤러가 2"
    TargetPattern = "Galaga 2"
    BasePattern = @(
        "Galaga.*2",
        "Galaga.*ii",
        "2.*Galaga",
        "Galaga.*Two"
    )
},
@{
    Name = "건스타 히어로즈"
    TargetPattern = "Gunstar Heroes"
    BasePattern = @(
        "Gunstar.*Heroes",
        "Heroes.*Gunstar",
        "Gunstar.*Hero"
    )
},
@{
    Name = "검용전설 야이바"
    TargetPattern = "Kenyuu Densetsu Yaiba"
    BasePattern = @(
        "Kenyuu.*Densetsu.*Yaiba",
        "Densetsu.*Yaiba.*Kenyuu",
        "Yaiba.*Kenyuu.*Densetsu"
    )
},
@{
    Name = "고지라 - 괴수 대진격"
    TargetPattern = "Gojira - Kaijuu Daishingeki"
    BasePattern = @(
        "Gojira.*Kaijuu.*Daishingeki",
        "Kaijuu.*Daishingeki.*Gojira",
        "Daishingeki.*Gojira.*Kaijuu"
    )
},
@{
    Name = "괴도 세인트 테일 - 천사소녀 네티"
    TargetPattern = "Kaitou Saint Tail"
    BasePattern = @(
        "Kaitou.*Saint.*Tail",
        "Saint.*Tail.*Kaitou",
        "Tail.*Kaitou.*Saint"
    )
},
@{
    Name = "귀신동자 젠키"
    TargetPattern = "Kishin Douji Zenki"
    BasePattern = @(
        "Kishin.*Douji.*Zenki",
        "Douji.*Zenki.*Kishin",
        "Zenki.*Kishin.*Douji"
    )
},
@{
    Name = "그리핀"
    TargetPattern = "Griffin"
    BasePattern = @(
        "Griffin",
        "Griff.*in",
        "Grif.*fin"
    )
},

@{
    Name = "그린독 - 비치 서퍼 듀드!"
    TargetPattern = "Greendog - The Beached Surfer Dude!"
    BasePattern = @(
        "Greendog.*Beached.*Surfer.*Dude",
        "Beached.*Surfer.*Dude.*Greendog",
        "Dude.*Greendog.*Beached.*Surfer"
    )
},
@{
    Name = "나조뿌요 - 아르르의 루"
    TargetPattern = "Nazo Puyo Arle no Roux"
    BasePattern = @(
        "Nazo.*Puyo.*Arle.*Roux",
        "Puyo.*Arle.*Roux.*Nazo",
        "Roux.*Nazo.*Puyo.*Arle"
    )
},

@{
    Name = "나조뿌요 2"
    TargetPattern = "Nazo Puyo 2"
    BasePattern = @(
        "Nazo.*Puyo.*2",
        "Nazo.*Puyo.*ii",
        "Puyo.*2.*Nazo",
        "Nazo.*Puyo.*Two"
    )
},
@{
    Name = "나조뿌요 1"
    TargetPattern = "Nazo Puyo"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*Nazo.*Puyo",
        "^(?!.*(?:2|3|II|III)).*Puyo.*Nazo",
        "^(?!.*(?:2|3|II|III)).*Nazo.*Puy"
    )
},

@{
    Name = "닌쿠 2 - 천구룡으로 가는 길"
    TargetPattern = "Ninku 2 - Tenkuuryuu e no Michi"
    BasePattern = @(
        "Ninku.*2.*Tenkuuryuu.*Michi",
        "Tenkuuryuu.*Michi.*Ninku.*2",
        "Michi.*Ninku.*Two.*Tenkuuryuu"
    )
},

@{
    Name = "닌쿠 외전 - 히로유키 대활극"
    TargetPattern = "Ninku Gaiden - Hiroyuki Daikatsugeki"
    BasePattern = @(
        "Ninku.*Gaiden.*Hiroyuki.*Daikatsugeki",
        "Gaiden.*Hiroyuki.*Daikatsugeki.*Ninku",
        "Daikatsugeki.*Ninku.*Gaiden.*Hiroyuki"
    )
},

@{
    Name = "닌쿠 1"
    TargetPattern = "Ninku"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III|Gaiden|Tenkuuryuu|Hiroyuki)).*Ninku",
        "^(?!.*(?:2|3|II|III|Gaiden|Tenkuuryuu|Hiroyuki)).*Nink.*u",
        "^(?!.*(?:2|3|II|III|Gaiden|Tenkuuryuu|Hiroyuki)).*Nin.*ku"
    )
},
@{
    Name = "덩크 키즈"
    TargetPattern = "Dunk Kids"
    BasePattern = @(
        "Dunk.*Kids",
        "Kids.*Dunk",
        "Dunk.*Kid"
    )
},
@{
    Name = "데저트 스트라이크 - 걸프로의 귀환"
    TargetPattern = "Desert Strike - Return to the Gulf"
    BasePattern = @(
        "Desert.*Strike.*Return.*Gulf",
        "Strike.*Return.*Gulf.*Desert",
        "Gulf.*Desert.*Strike.*Return"
    )
},
@{
    Name = "데저트 스피드트랩 - 로드 러너와 와일 E. 코요테"
    TargetPattern = "Desert Speedtrap Starring Road Runner and Wile E. Coyote"
    BasePattern = @(
        "Desert.*Speedtrap.*Road.*Runner.*Wile.*Coyote",
        "Speedtrap.*Road.*Runner.*Wile.*Coyote.*Desert",
        "Road.*Runner.*Wile.*Coyote.*Desert.*Speedtrap"
    )
},

@{
    Name = "도날드의 매지컬 월드"
    TargetPattern = "Donald no Magical World"
    BasePattern = @(
        "Donald.*Magical.*World",
        "Magical.*World.*Donald",
        "World.*Donald.*Magical"
    )
},
@{
    Name = "도라에몽 - 노라노스케의 야망"
    TargetPattern = "Doraemon - Noranosuke no Yabou"
    BasePattern = @(
        "Doraemon.*Noranosuke.*Yabou",
        "Noranosuke.*Yabou.*Doraemon",
        "Yabou.*Doraemon.*Noranosuke"
    )
},
@{
    Name = "도라에몽 - 와쿠와쿠 포켓 파라다이스"
    TargetPattern = "Doraemon - Waku Waku Pocket Paradise"
    BasePattern = @(
        "Doraemon.*Waku.*Pocket.*Paradise",
        "Waku.*Pocket.*Paradise.*Doraemon",
        "Paradise.*Doraemon.*Waku.*Pocket"
    )
},
@{
    Name = "드래곤 - 브루스 리 이야기"
    TargetPattern = "Dragon - The Bruce Lee Story"
    BasePattern = @(
        "Dragon.*Bruce.*Lee.*Story",
        "Bruce.*Lee.*Story.*Dragon",
        "Story.*Dragon.*Bruce.*Lee"
    )
},
@{
    Name = "드롭존"
    TargetPattern = "Dropzone"
    BasePattern = @(
        "Dropzone",
        "Drop.*zone",
        "Zone.*Drop"
    )
},

@{
    Name = "라스트 액션 히어로"
    TargetPattern = "Last Action Hero"
    BasePattern = @(
        "Last.*Action.*Hero",
        "Action.*Hero.*Last",
        "Hero.*Last.*Action"
    )
},
@{
    Name = "렌 호크와 스팀피의 쉐이븐 억 퀘스트"
    TargetPattern = "Quest for the Shaven Yak Starring Ren Hoek & Stimpy"
    BasePattern = @(
        "Quest.*Shaven.*Yak.*Ren.*Hoek.*Stimpy",
        "Shaven.*Yak.*Ren.*Hoek.*Stimpy.*Quest",
        "Yak.*Quest.*Shaven.*Ren.*Hoek.*Stimpy"
    )
},
@{
    Name = "라이즈 오브 더 로봇"
    TargetPattern = "Rise of the Robots"
    BasePattern = @(
        "Rise.*of.*the.*Robots",
        "of.*the.*Robots.*Rise",
        "Rise.*Robot",
        "Robots.*Rise.*the"
    )
},
@{
    Name = "로열 스톤 - 열려진 시간의 문"
    TargetPattern = "Royal Stone - Hirakareshi Toki no Tobira"
    BasePattern = @(
        "Royal.*Stone.*Hirakareshi.*Toki.*Tobira",
        "Stone.*Hirakareshi.*Toki.*Tobira.*Royal",
        "Tobira.*Royal.*Stone.*Hirakareshi.*Toki"
    )
},

@{
    Name = "메가맨 - 록맨"
    TargetPattern = "Mega Man"
    BasePattern = @(
        "Mega.*Man",
        "Man.*Mega",
        "Mega.*Rock.*Man"
    )
},
@{
    Name = "루나 - 산보하는 학원"
    TargetPattern = "Lunar - Sanposuru Gakuen"
    BasePattern = @(
        "Lunar.*Sanposuru.*Gakuen",
        "Sanposuru.*Gakuen.*Lunar",
        "Gakuen.*Lunar.*Sanposuru"
    )
},
@{
    Name = "리스타 - 더 슈팅 스타"
    TargetPattern = "Ristar - The Shooting Star"
    BasePattern = @(
        "Ristar.*Shooting.*Star",
        "Shooting.*Star.*Ristar",
        "Star.*Ristar.*Shooting"
    )
},
@{
    Name = "마도물어 A - 두근두근 바캉스"
    TargetPattern = "Madou Monogatari A - Dokidoki Vacation"
    BasePattern = @(
        "Madou.*Monogatari.*A.*Dokidoki.*Vacation",
        "Monogatari.*A.*Dokidoki.*Vacation.*Madou",
        "Dokidoki.*Vacation.*Madou.*Monogatari.*A"
    )
},
@{
    Name = "마도물어 I - 3개의 마도구"
    TargetPattern = "Madou Monogatari I - 3-Tsu no Madoukyuu"
    BasePattern = @(
        "Madou.*Monogatari.*I.*3.*Madoukyuu",
        "Madou.*Monogatari.*3.*Madoukyuu",
        "Monogatari.*I.*Madoukyuu.*3.*Madou",
        "3.*Madoukyuu.*Madou.*Monogatari.*I"
    )
},
@{
    Name = "마도물어 II - 아르르 16세"
    TargetPattern = "Madou Monogatari II - Arle 16-Sai"
    BasePattern = @(
        "Madou.*Monogatari.*II.*Arle.*16.*Sai",
        "Monogatari.*II.*16.*Sai.*Arle.*Madou",
        "Arle.*16.*Sai.*Madou.*Monogatari.*II"
    )
},
@{
    Name = "마도물어 III - 궁극의 여왕님"
    TargetPattern = "Madou Monogatari III - Kyuukyoku Joou-sama"
    BasePattern = @(
        "Madou.*Monogatari.*III.*Kyuukyoku.*Joou.*sama",
        "Monogatari.*III.*Joou.*sama.*Kyuukyoku.*Madou",
        "Joou.*sama.*Madou.*Monogatari.*III.*Kyuukyoku"
    )
},
@{
    Name = "마르코의 매직 풋볼"
    TargetPattern = "Marko's Magic Football"
    BasePattern = @(
        "Marko.*Magic.*Football",
        "Magic.*Football.*Marko",
        "Football.*Marko.*Magic"
    )
},

@{
    Name = "마법기사 레이어스 2 - 매직 나이트 제작기"
    TargetPattern = "Magic Knight Rayearth 2 - Making of Magic Knight"
    BasePattern = @(
        "Magic.*Knight.*Rayearth.*2.*Making.*Magic.*Knight",
        "Knight.*Rayearth.*2.*Making.*Magic.*Knight.*Magic",
        "Rayearth.*2.*Making.*Magic.*Knight.*Magic.*Knight"
    )
},

@{
    Name = "마법기사 레이어스 1"
    TargetPattern = "Magic Knight Rayearth"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III|Making|make)).*Magic.*Knight.*Rayearth",
        "^(?!.*(?:2|3|II|III|Making|make)).*Knight.*Rayearth.*Magic",
        "^(?!.*(?:2|3|II|III|Making|make)).*Rayearth.*Magic.*Knight"
    )
},

@{
    Name = "마법의 타루루토군"
    TargetPattern = "Magical Taruruuto-kun"
    BasePattern = @(
        "Magical.*Taruruuto.*kun",
        "Taruruuto.*kun.*Magical",
        "Taruruuto.*Magical.*kun"
    )
},
@{
    Name = "마이크로 머신 2 - 터보 토너먼트"
    TargetPattern = "Micro Machines 2 - Turbo Tournament"
    BasePattern = @(
        "Micro.*Machines.*2.*Turbo.*Tournament",
        "Machines.*2.*Turbo.*Tournament.*Micro",
        "Turbo.*Tournament.*Micro.*Machines.*2"
    )
},
@{
    Name = "마이티 모핀 파워레인저 - 더 무비"
    TargetPattern = "Mighty Morphin Power Rangers - The Movie"
    BasePattern = @(
        "Mighty.*Morphin.*Power.*Rangers.*Movie",
        "Morphin.*Power.*Rangers.*Movie.*Mighty",
        "Power.*Rangers.*Movie.*Mighty.*Morphin"
    )
},
@{
    Name = "마이티 모핀 파워레인저"
    TargetPattern = "Mighty Morphin Power Rangers"
    BasePattern = @(
        "^(?!.*(?:2|3|copy|movie)).*Mighty.*Morphin.*Power.*Rangers",
        "^(?!.*(?:2|3|copy|movie)).*Morphin.*Power.*Rangers.*Mighty",
        "^(?!.*(?:2|3|copy|movie)).*Power.*Rangers.*Mighty.*Morphin"
    )
},
@{
    Name = "마피"
    TargetPattern = "Mappy"
    BasePattern = @(
        "Mappy"
    )
},
@{
    Name = "몬스터 트럭 워즈"
    TargetPattern = "Monster Truck Wars"
    BasePattern = @(
        "Monster.*Truck.*Wars",
        "Truck.*Wars.*Monster",
        "Wars.*Monster.*Truck"
    )
},
@{
    Name = "몰도리안 - 빛과 어둠의 자매"
    TargetPattern = "Moldorian - Hikari to Yami no Sister"
    BasePattern = @(
        "Moldorian.*Hikari.*Yami.*Sister",
        "Hikari.*Yami.*Sister.*Moldorian",
        "Yami.*Sister.*Moldorian.*Hikari"
    )
},
@{
    Name = "미소녀 전사 세일러문 S"
    TargetPattern = "Bishoujo Senshi Sailor Moon S"
    BasePattern = @(
        "Bishoujo.*Senshi.*Sailor.*Moon.*S",
        "Senshi.*Sailor.*Moon.*S.*Bishoujo",
        "Sailor.*Moon.*S.*Bishoujo.*Senshi"
    )
},
@{
    Name = "배트맨 포에버"
    TargetPattern = "Batman Forever"
    BasePattern = @(
        "^(?!.*(?:Return|Adventure|Robin)).*Batman.*Forever",
        "^(?!.*(?:Return|Adventure|Robin)).*Forever.*Batman",
        "^(?!.*(?:Return|Adventure|Robin)).*Bat.*man.*Forever"
    )
},
@{
    Name = "배트맨과 로빈의 모험"
    TargetPattern = "Adventures of Batman & Robin, The"
    BasePattern = @(
        "^(?!.*(?:Return|forever)).*Adventures.*Batman.*Robin",
        "^(?!.*(?:Return|forever)).*Batman.*Robin.*Adventures",
        "^(?!.*(?:Return|forever)).*Robin.*Adventures.*Batman"
    )
},

@{
    Name = "배틀토드"
    TargetPattern = "Battletoads"
    BasePattern = @(
        "Battletoads",
        "Battle.*Toads",
        "Toads.*Battle"
    )
},
@{
    Name = "뱀파이어 - 마스터 오브 다크니스"
    TargetPattern = "Vampire - Master of Darkness"
    BasePattern = @(
        "Vampire.*Master.*Darkness",
        "Master.*Darkness.*Vampire",
        "Darkness.*Vampire.*Master"
    )
},
@{
    Name = "버스터 볼"
    TargetPattern = "Buster Ball"
    BasePattern = @(
        "Buster.*Ball",
        "Ball.*Buster",
        "Bus.*ter.*Ball"
    )
},
@{
    Name = "버스터 파이트"
    TargetPattern = "Buster Fight"
    BasePattern = @(
        "Buster.*Fight",
        "Fight.*Buster",
        "Bus.*ter.*Fight"
    )
},
@{
    Name = "버스트 어 무브"
    TargetPattern = "Bust-A-Move"
    BasePattern = @(
        "Bust.*A.*Move",
        "A.*Move.*Bust",
        "Move.*Bust.*A"
    )
},
@{
    Name = "버추어 파이터 애니메이션"
    TargetPattern = "Virtua Fighter Animation"
    BasePattern = @(
        "Virtua.*Fighter.*Animation",
        "Fighter.*Animation.*Virtua",
        "Animation.*Virtua.*Fighter"
    )
},
@{
    Name = "벅스 버니 인 더블 트러블"
    TargetPattern = "Bugs Bunny in Double Trouble"
    BasePattern = @(
        "Bugs.*Bunny.*Double.*Trouble",
        "Bunny.*Double.*Trouble.*Bugs",
        "Double.*Trouble.*Bugs.*Bunny"
    )
},
@{
    Name = "베렌스타인 베어즈의 캠핑 어드벤처"
    TargetPattern = "Berenstain Bears' Camping Adventure, The"
    BasePattern = @(
        "Berenstain.*Bears.*Camping.*Adventure",
        "Bears.*Camping.*Adventure.*Berenstain",
        "Camping.*Adventure.*Berenstain.*Bears"
    )
},
@{
    Name = "베를린의 벽"
    TargetPattern = "Berlin no Kabe"
    BasePattern = @(
        "Berlin.*no.*Kabe",
        "no.*Kabe.*Berlin",
        "Kabe.*Berlin.*no"
    )
},

@{
    Name = "베어 너클 II - 스트리츠 오브 레이지 2"
    TargetPattern = "Streets of Rage II"
    BasePattern = @(
        "Streets.*of.*Rage.*II",
        "of.*Rage.*II.*Streets",
        "Rage.*II.*Streets.*of"
    )
},

@{
    Name = "베어 너클 - 스트리츠 오브 레이지"
    TargetPattern = "Streets of Rage"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*Streets.*of.*Rage",
        "^(?!.*(?:2|3|II|III)).*of.*Rage.*Streets",
        "^(?!.*(?:2|3|II|III)).*Rage.*Streets.*of"
    )
},
@{
    Name = "비비스와 버트헤드"
    TargetPattern = "Beavis and Butt-Head"
    BasePattern = @(
        "Beavis.*Butt.*Head",
        "Butt.*Head.*Beavis",
        "Head.*Beavis.*Butt"
    )
},
@{
    Name = "빼앗기고 말겠는가"
    TargetPattern = "Torarete Tamaruka"
    BasePattern = @(
        "Torarete.*Tamaruka",
        "Tamaruka.*Torarete",
        "Tora.*rete.*Tama.*ruka"
    )
},
@{
    Name = "뽀빠이의 비치 발리볼"
    TargetPattern = "Popeye no Beach Volleyball"
    BasePattern = @(
        "Popeye.*Beach.*Volleyball",
        "Beach.*Volleyball.*Popeye",
        "Volleyball.*Popeye.*Beach"
    )
},

@{
    Name = "뿌요 뿌요 2"
    TargetPattern = "Puyo Puyo Tsuu"
    BasePattern = @(
        "Puyo.*Puyo.*Tsuu",
        "Puyo.*Tsuu.*Puyo",
        "Tsuu.*Puyo.*Puyo"
    )
},
@{
    Name = "뿌요 뿌요 1"
    TargetPattern = "Puyo Puyo"
    BasePattern = @(
        "^(?!.*(?:2|tsu|II|nazo)).*Puyo.*Puyo"
    )
},
@{
    Name = "사무라이 쇼다운"
    TargetPattern = "Samurai Shodown"
    BasePattern = @(
        "Samurai.*Shodown",
        "Samurai.*Spirits",
        "Shodown.*Samurai",
        "Samu.*rai.*Shodo.*wn"
    )
},

@{
    Name = "샤이닝 포스 외전 - 최후의 대결"
    TargetPattern = "Shining Force Gaiden - Final Conflict"
    BasePattern = @(
        "Shining.*Force.*Gaiden.*Final.*Conflict",
        "Force.*Gaiden.*Final.*Conflict.*Shining",
        "Gaiden.*Final.*Conflict.*Shining.*Force"
    )
},
@{
    Name = "샤이닝 포스 외전 II - 사신의 각성"
    TargetPattern = "Shining Force Gaiden II - Jashin no Kakusei"
    BasePattern = @(
        "Shining.*Force.*Gaiden.*II.*Jashin.*Kakusei",
        "Force.*Gaiden.*II.*Jashin.*Kakusei.*Shining",
        "Gaiden.*II.*Jashin.*Kakusei.*Shining.*Force"
    )
},

@{
    Name = "샤이닝 포스 외전 - 원정, 사신의 나라로"
    TargetPattern = "Shining Force Gaiden - Ensei, Jashin no Kuni e"
    BasePattern = @(
        "Shining.*Force.*Gaiden.*Ensei.*Jashin.*Kuni",
        "Force.*Gaiden.*Ensei.*Jashin.*Kuni.*Shining",
        "Gaiden.*Ensei.*Jashin.*Kuni.*Shining.*Force"
    )
},
@{
    Name = "샤크 푸"
    TargetPattern = "Shaq Fu"
    BasePattern = @(
        "Shaq.*Fu",
        "Fu.*Shaq"
    )
},

@{
    Name = "서프 닌자"
    TargetPattern = "Surf Ninjas"
    BasePattern = @(
        "Surf.*Ninjas",
        "Ninjas.*Surf"
    )
},
@{
    Name = "소닉 더 헤지혹 - 트리플 트러블"
    TargetPattern = "Sonic The Hedgehog - Triple Trouble"
    BasePattern = @(
        "Sonic.*The.*Hedgehog.*Triple.*Trouble",
        "Sonic.*Triple.*Trouble",
        "Triple.*Trouble.*Sonic",
        "The.*Hedgehog.*Sonic.*Triple.*Trouble"
    )
},



@{
    Name = "소닉 드리프트 2"
    TargetPattern = "Sonic Drift 2"
    BasePattern = @(
        "Sonic.*Drift.*2",
        "Drift.*2.*Sonic",
        "2.*Sonic.*Drift"
    )
},

@{
    Name = "소닉 드리프트 1"
    TargetPattern = "Sonic Drift"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*Sonic.*Drift",
        "^(?!.*(?:2|3|II|III)).*Drift.*Sonic"
    )
},

@{
    Name = "소닉 래버린스"
    TargetPattern = "Sonic Labyrinth"
    BasePattern = @(
        "Sonic.*Labyrinth",
        "Labyrinth.*Sonic"
    )
},

@{
    Name = "슈퍼 모모타로 전철 III"
    TargetPattern = "Super Momotarou Dentetsu III"
    BasePattern = @(
        "Super.*Momotarou.*Dentetsu.*III",
        "Momotarou.*Dentetsu.*III.*Super",
        "Dentetsu.*III.*Super.*Momotarou"
    )
},

@{
    Name = "슈퍼 배틀탱크"
    TargetPattern = "Super Battletank"
    BasePattern = @(
        "Super.*Battletank",
        "Battletank.*Super"
    )
},

@{
    Name = "슈퍼 스타 워즈 - 제다이의 귀환"
    TargetPattern = "Super Star Wars - Return of the Jedi"
    BasePattern = @(
        "Super.*Star.*Wars.*Return.*of.*the.*Jedi",
        "Star.*Wars.*Return.*of.*the.*Jedi.*Super",
        "Return.*of.*the.*Jedi.*Super.*Star.*Wars"
    )
},

@{
    Name = "스타 트렉 - 넥스트 제너레이션 - 어드밴스드 홀로덱 튜토리얼"
    TargetPattern = "Star Trek - The Next Generation - The Advanced Holodeck Tutorial"
    BasePattern = @(
        "Star.*Trek.*Next.*Generation.*Advanced.*Holodeck.*Tutorial",
        "Star.*Trek.*Next.*Generation.*Advanced.*Holodeck.*Tutorial",
        "Next.*Generation.*Advanced.*Holodeck.*Tutorial.*Star.*Trek",
        "The.*Advanced.*Holodeck.*Tutorial.*Star.*Trek"
    )
},
@{
    Name = "스타 트렉 제너레이션즈 - 비욘드 더 넥서스"
    TargetPattern = "Star Trek Generations - Beyond the Nexus"
    BasePattern = @(
        "Star.*Trek.*Generations.*Beyond.*the.*Nexus",
        "Generations.*Beyond.*the.*Nexus.*Star.*Trek",
        "Beyond.*the.*Nexus.*Star.*Trek.*Generations"
    )
},

@{
    Name = "스타게이트"
    TargetPattern = "Stargate"
    BasePattern = @(
        "Stargate"
    )
},

@{
    Name = "스파이더맨 - 엑스맨 - 아케이드의 복수"
    TargetPattern = "Spider-Man - X-Men - Arcade's Revenge"
    BasePattern = @(
        "Spider.*Man.*X-Men.*Arcade.*Revenge",
        "Spider.*X.*Arcade.*Revenge",
        "X-Men.*Arcade's.*Revenge.*Spider.*Man",
        "Arcade's.*Revenge.*Spider.*Man.*X-Men"
    )
},

@{
    Name = "슬램덩크 - 승리를 향한 스타팅 5"
    TargetPattern = "From TV Animation Slam Dunk - Shouri e no Starting 5"
    BasePattern = @(
        "From.*TV.*Animation.*Slam.*Dunk.*Shouri.*Starting.*5",
        "Slam.*Dunk.*Shouri.*e.*no.*Starting.*5.*TV.*Animation",
        "Shouri.*e.*no.*Starting.*5.*Slam.*Dunk.*TV.*Animation"
    )
},

@{
    Name = "시카고 신디케이트"
    TargetPattern = "Chicago Syndicate"
    BasePattern = @(
        "Chicago.*Syndicate",
        "Syndicate.*Chicago"
    )
},

@{
    Name = "실반 테일"
    TargetPattern = "Sylvan Tale"
    BasePattern = @(
        "Sylvan.*Tale",
        "Tale.*Sylvan"
    )
},

@{
    Name = "심슨 가족 - 바트맨과 방사능 맨"
    TargetPattern = "Simpsons, The - Bartman Meets Radioactive Man"
    BasePattern = @(
        "Simpsons.*Bartman.*Meets.*Radioactive.*Man",
        "Bartman.*Meets.*Radioactive.*Man.*Simpsons",
        "Radioactive.*Man.*Simpsons.*Bartman.*Meets"
    )
},



@{
    Name = "아랑전설 스페셜"
    TargetPattern = "Fatal Fury Special"
    BasePattern = @(
        "Fatal.*Fury.*Special",
        "Fatal.*Fury",
        "Fury.*Special.*Fatal"
    )
},

@{
    Name = "아웃런"
    TargetPattern = "OutRun"
    BasePattern = @(
        "^(?!.*(?:2|euro|II|III)).*OutRun",
        "^(?!.*(?:2|euro|II|III)).*Out.*Run"
    )
},

@{
    Name = "아레나 - 죽음의 미로"
    TargetPattern = "Arena - Maze of Death"
    BasePattern = @(
        "Arena.*Maze.*Death",
        "Maze.*Death.*Arena"
    )
},

@{
    Name = "아이언맨 X-O 매노워 인 헤비 메탈"
    TargetPattern = "Iron Man X-O Manowar in Heavy Metal"
    BasePattern = @(
        "Iron.*Man.*X.*O.*Manowar.*Heavy.*Metal",
        "X.*O.*Manowar.*Heavy.*Metal.*Iron.*Man",
        "Manowar.*Heavy.*Metal.*Iron.*Man.*X.*O"
    )
},

@{
    Name = "알레스테 2"
    TargetPattern = "GG Aleste II"
    BasePattern = @(
        "GG.*Aleste.*II",
        "GG.*Aleste.*2",
        "Aleste.*ii"
    )
},

@{
    Name = "알레스테"
    TargetPattern = "GG Aleste"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*GG.*Aleste",
        "^(?!.*(?:2|3|II|III)).*Aleste",
        "^(?!.*(?:2|3|II|III)).*Aleste.*GG"
    )
},

@{
    Name = "액스 배틀러 - 골든 액스의 전설"
    TargetPattern = "Ax Battler - A Legend of Golden Axe"
    BasePattern = @(
        "Ax.*Battler.*A.*Legend.*Golden.*Axe",
        "Battler.*A.*Legend.*Golden.*Axe.*Ax",
        "Legend.*Golden.*Axe.*Ax.*Battler"
    )
},

@{
    Name = "어둠 속의 여정 - 스트라이더 리턴즈"
    TargetPattern = "Journey from Darkness - Strider Returns"
    BasePattern = @(
        "Journey.*Darkness.*Strider.*Returns",
        "Darkness.*Strider.*Returns.*Journey",
        "Strider.*Returns.*Journey.*Darkness"
    )
},

@{
    Name = "어반 스트라이크"
    TargetPattern = "Urban Strike"
    BasePattern = @(
        "Urban.*Strike",
        "Strike.*Urban"
    )
},


@{
    Name = "엑스맨 - 게임마스터의 유산"
    TargetPattern = "X-Men - Gamemaster's Legacy"
    BasePattern = @(
        "X-Men.*Gamemaster's.*Legacy",
        "Gamemaster's.*Legacy.*X-Men"
    )
},

@{
    Name = "엑스맨"
    TargetPattern = "X-Men"
    BasePattern = @(
        "^(?!.*(?:Revenge|World|Gamemaster|Spider|Legacy|Mojo)).*X.*Men"
    )
},


@{
    Name = "여신전생 외전 - 라스트 바이블 스페셜"
    TargetPattern = "Megami Tensei Gaiden - Last Bible Special"
    BasePattern = @(
        "Megami.*Tensei.*Gaiden.*Last.*Bible.*Special",
        "Tensei.*Gaiden.*Last.*Bible.*Special.*Megami",
        "Gaiden.*Last.*Bible.*Special.*Megami.*Tensei"
    )
},

@{
    Name = "오아시스의 수호자"
    TargetPattern = "Defenders of Oasis"
    BasePattern = @(
        "Defenders.*Oasis",
        "Oasis.*Defenders"
    )
},

@{
    Name = "와갼 랜드"
    TargetPattern = "Wagyan Land"
    BasePattern = @(
        "Wagyan.*Land",
        "Land.*Wagyan"
    )
},
@{
    Name = "유유백서 - 멸하는 자의 역습"
    TargetPattern = "Yu Yu Hakusho - Horobishimono no Gyakushuu"
    BasePattern = @(
        "Yu.*Yu.*Hakusho.*Horobishimono.*Gyakushuu",
        "Yu.*Hakusho.*Horobishimono.*Gyakushuu.*Yu",
        "Horobishimono.*Gyakushuu.*Yu.*Yu.*Hakusho"
    )
},

@{
    Name = "유유백서 II - 격투! 7강의 싸움"
    TargetPattern = "Yu Yu Hakusho 2 - Gekitou! Nanakyou no Tatakai"
    BasePattern = @(
        "Yu.*Yu.*Hakusho.*2.*Gekitou.*Nanakyou.*no.*Tatakai",
        "Yu.*Yu.*Hakusho.*Gekitou.*Nanakyou.*no.*Tatakai",
        "Yu.*Hakusho.*2.*Gekitou.*Tatakai.*Nanakyou",
        "Yu.*Hakusho.*Gekitou.*Tatakai.*Nanakyou",
        "Gekitou.*Nanakyou.*no.*Tatakai.*Yu.*Hakusho.*2"
    )
},

@{
    Name = "이치와 스크래치 게임"
    TargetPattern = "Itchy And Scratchy Game, The"
    BasePattern = @(
        "Itchy.*Scratchy.*Game",
        "Itchy.*Scratchy",
        "Scratchy.*Game.*Itchy"
    )
},

@{
    Name = "이터널 레전드 - 영원의 전설"
    TargetPattern = "Eternal Legend - Eien no Densetsu"
    BasePattern = @(
        "Eternal.*Legend.*Eien.*Densetsu",
        "Legend.*Eien.*Densetsu.*Eternal",
        "Eien.*Densetsu.*Eternal.*Legend"
    )
},

@{
    Name = "인디아나 존스와 최후의 성전"
    TargetPattern = "Indiana Jones and the Last Crusade"
    BasePattern = @(
        "Indiana.*Jones.*Last.*Crusade",
        "Jones.*Last.*Crusade.*Indiana",
        "Last.*Crusade.*Indiana.*Jones"
    )
},

@{
    Name = "저지 드레드"
    TargetPattern = "Judge Dredd"
    BasePattern = @(
        "Judge.*Dredd",
        "Dredd.*Judge"
    )
},

@{
    Name = "제임스 폰드 2 - 코드네임 로보코드"
    TargetPattern = "James Pond II - Codename RoboCod"
    BasePattern = @(
        "James.*Pond.*II.*Codename.*RoboCod",
        "Pond.*II.*Codename.*RoboCod.*James",
        "Codename.*RoboCod.*James.*Pond.*II"
    )
},

@{
    Name = "제임스 폰드 3 - 오퍼레이션 스타피쉬"
    TargetPattern = "James Pond 3 - Operation Starfi5h"
    BasePattern = @(
        "James.*Pond.*3.*Operation.*Starfi5h",
        "Pond.*3.*Operation.*Starfi5h.*James",
        "Operation.*Starfi5h.*James.*Pond.*3"
    )
},

@{
    Name = "줄 - N차원의 닌자"
    TargetPattern = "Zool - Ninja of the Nth Dimension"
    BasePattern = @(
        "Zool.*Ninja.*Nth.*Dimension",
        "Ninja.*Nth.*Dimension.*Zool",
        "Nth.*Dimension.*Zool.*Ninja"
    )
},

@{
    Name = "쥬라기 공원 - 더 로스트 월드"
    TargetPattern = "Lost World, The - Jurassic Park"
    BasePattern = @(
        "Lost.*World.*Jurassic.*Park",
        "World.*jurassic.*Park.*Lost",
        "Jurassic.*Park"
    )
},

@{
    Name = "차칸"
    TargetPattern = "Chakan"
    BasePattern = @(
        "Chakan"
    )
},

@{
    Name = "초상화 - 유키 아키라"
    TargetPattern = "GG Portrait - Yuuki Akira"
    BasePattern = @(
        "GG.*Portrait.*Yuuki.*Akira",
        "Portrait.*Yuuki.*Akira.*GG",
        "Yuuki.*Akira.*GG.*Portrait"
    )
},

@{
    Name = "초상화 - 파이 첸"
    TargetPattern = "GG Portrait - Pai Chen"
    BasePattern = @(
        "GG.*Portrait.*Pai.*Chen",
        "Portrait.*Pai.*Chen.*GG",
        "Pai.*Chen.*GG.*Portrait"
    )
},

@{
    Name = "캡틴 아메리카와 어벤저스"
    TargetPattern = "Captain America and the Avengers"
    BasePattern = @(
        "Captain.*America.*and.*Avengers",
        "America.*and.*Avengers.*Captain",
        "Avengers.*Captain.*America"
    )
},

@{
    Name = "컷스로트 아일랜드"
    TargetPattern = "CutThroat Island"
    BasePattern = @(
        "CutThroat.*Island",
        "Island.*CutThroat"
    )
},

@{
    Name = "코카콜라 키드"
    TargetPattern = "Coca-Cola Kid"
    BasePattern = @(
        "Coca.*Cola.*Kid",
        "Kid.*Coca.*Cola"
    )
},

@{
    Name = "크레용 신짱 - 대결! 캔탐 패닉!!"
    TargetPattern = "Crayon Shin-chan - Taiketsu! Kantam Panic!!"
    BasePattern = @(
        "Crayon.*Shin-chan.*Taiketsu!.*Kantam.*Panic",
        "Shin-chan.*Taiketsu.*Kantam.*Panic!!.*Crayon",
        "Taiketsu!.*Kantam.*Panic.*Crayon.*Shin-chan"
    )
},

@{
    Name = "크리스탈 워리어즈"
    TargetPattern = "Crystal Warriors"
    BasePattern = @(
        "Crystal.*Warriors",
        "Warriors.*Crystal"
    )
},

@{
    Name = "클리프행어"
    TargetPattern = "Cliffhanger"
    BasePattern = @(
        "Cliffhanger"
    )
},

@{
    Name = "타마와 친구들 - 3초우메 공원 타마림픽"
    TargetPattern = "Tama & Friends - 3 Choume Kouen Tamalympic"
    BasePattern = @(
        "Tama.*Friends.*3.*Choume.*Kouen.*Tamalympic",
        "Friends.*3.*Choume.*Kouen.*Tamalympic.*Tama",
        "3.*Choume.*Kouen.*Tamalympic.*Tama.*Friends"
    )
},

@{
    Name = "타잔 - 정글의 왕"
    TargetPattern = "Tarzan - Lord of the Jungle"
    BasePattern = @(
        "Tarzan.*Lord.*Jungle",
        "Lord.*Jungle.*Tarzan",
        "Jungle.*Tarzan.*Lord"
    )
},

@{
    Name = "테일스핀"
    TargetPattern = "TaleSpin"
    BasePattern = @(
        "TaleSpin",
        "Tale.*Spin"
    )
},

@{
    Name = "테일즈 어드벤처"
    TargetPattern = "Tails Adventure"
    BasePattern = @(
        "Tails.*Adventure",
        "Adventure.*Tails"
    )
},

@{
    Name = "테일즈의 스카이패트롤"
    TargetPattern = "Tails no Skypatrol"
    BasePattern = @(
        "Tails.*Skypatrol",
        "Skypatrol.*Tails"
    )
},

@{
    Name = "템포 주니어"
    TargetPattern = "Tempo Jr."
    BasePattern = @(
        "Tempo.*Jr.",
        "Jr.*Tempo"
    )
},

@{
    Name = "톰과 제리 - 더 무비"
    TargetPattern = "Tom and Jerry - The Movie"
    BasePattern = @(
        "Tom.*Jerry.*Movie",
        "Jerry.*Movie.*Tom",
        "Jerry.*Movie.*Tom"
    )
},

@{
    Name = "트루 라이즈"
    TargetPattern = "True Lies"
    BasePattern = @(
        "True.*Lies",
        "Lies.*True"
    )
},

@{
    Name = "틴틴 인 티베트"
    TargetPattern = "Tintin in Tibet"
    BasePattern = @(
        "Tintin.*in.*Tibet",
        "in.*Tibet.*Tintin"
    )
},

@{
    Name = "판타지 스타 어드벤처"
    TargetPattern = "Phantasy Star Adventure"
    BasePattern = @(
        "Phantasy.*Star.*Adventure",
        "Star.*Adventure.*Phantasy",
        "Adventure.*Phantasy.*Star"
    )
},

@{
    Name = "판타지 스타 외전"
    TargetPattern = "Phantasy Star Gaiden"
    BasePattern = @(
        "Phantasy.*Star.*Gaiden",
        "Star.*Gaiden.*Phantasy",
        "Gaiden.*Phantasy.*Star"
    )
},
@{
    Name = "판타지 존 기어 - 판타지 존"
    TargetPattern = "Fantasy Zone Gear - Fantasy Zone"
    BasePattern = @(
        "Fantasy.*Zone.*Gear.*Fantasy.*Zone",
        "Zone.*Gear.*Fantasy.*Zone.*Fantasy",
        "Fantasy.*Zone.*Gear",
        "Gear.*Fantasy.*Zone.*Fantasy.*Zone"
    )
},

@{
    Name = "팝 브레이커"
    TargetPattern = "Pop Breaker"
    BasePattern = @(
        "Pop.*Breaker",
        "Breaker.*Pop"
    )
},

@{
    Name = "팩 어택"
    TargetPattern = "Pac-Attack"
    BasePattern = @(
        "Pac-Attack",
        "Attack.*Pac"
    )
},

@{
    Name = "팬저 드라군 미니"
    TargetPattern = "Panzer Dragoon Mini"
    BasePattern = @(
        "Panzer.*Dragoon.*Mini",
        "Dragoon.*Mini.*Panzer",
        "Mini.*Panzer.*Dragoon"
    )
},

@{
    Name = "팬텀 2040"
    TargetPattern = "Phantom 2040"
    BasePattern = @(
        "Phantom.*2040",
        "2040.*Phantom"
    )
},

@{
    Name = "프라이멀 레이지"
    TargetPattern = "Primal Rage"
    BasePattern = @(
        "Primal.*Rage",
        "Rage.*Primal"
    )
},

@{
    Name = "프레이 - 수행 편"
    TargetPattern = "Fray - Shugyou Hen"
    BasePattern = @(
        "Fray.*Shugyou.*Hen",
        "Shugyou.*Hen.*Fray"
    )
},

@{
    Name = "피구왕 통키"
    TargetPattern = "Honoo no Toukyuuji - Dodge Danpei"
    BasePattern = @(
        "Honoo.*Toukyuuji.*Dodge.*Danpei",
        "Toukyuuji.*Dodge.*Danpei.*Honoo",
        "Toukyuuji.*Dodge.*Danpei.*Honoo"
    )
},

@{
    Name = "할리 전쟁"
    TargetPattern = "Halley Wars"
    BasePattern = @(
        "Halley.*Wars",
        "Wars.*Halley"
    )
},

@{
    Name = "헤드 버스터"
    TargetPattern = "Head Buster"
    BasePattern = @(
        "Head.*Buster",
        "Buster.*Head"
    )
},

@{
    Name = "효코리 효탄섬 - 효탄섬의 대항해"
    TargetPattern = "Hyokkori Hyoutan-jima - Hyoutan-jima no Daikoukai"
    BasePattern = @(
        "Hyokkori.*Hyoutan.*jima.*Hyoutan.*jima.*Daikoukai",
        "Hyoutan.*jima.*Hyoutan.*jima.*Daikoukai",
        "Hyoutan.*jima.*Daikoukai.*Hyoutan.*jima",
        "Daikoukai.*Hyoutan.*jima.*Hyoutan.*jima"
    )
},

@{
    Name = "후크"
    TargetPattern = "Hook"
    BasePattern = @(
        "Hook"
    )
}



)


# best 폴더가 없으면 생성
if (-not (Test-Path "best")) {
    New-Item -ItemType Directory -Path "best"
}


# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./best/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}


    # USA 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\best\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -notmatch "(?i)beta|demo") -and  # beta와 demo 제외                       
                      ($file.Name -match '\(.*USA.*?\)' -or $file.Name -match '\[.*USA.*?\]')
                  }

    # USA 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\best\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                         ($file.Name -notmatch "(?i)beta|demo") -and  # beta와 demo 제외
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to best folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")