﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(



@{
    Name = "(K) 위드 유 - 바라보고 싶어"
    TargetPattern = "(K) With You - Mitsumete Itai"
    BasePattern = @(
        "With.*You.*Mitsumete.*Itai",
        "With.*You.*Itai",
        "위드.*유.*바라.*보고.*싶어",
        "위드.*유.*Mitsumete",
        "With.*You",
        "Mitsumete.*Itai",
        "위드.*유",
        "바라.*보고.*싶어"
    )
},


@{
    Name = "(K) 마리 & 에리 - 두 사람의 아틀리에"
    TargetPattern = "(K) Alchemist Marie & Elie - Futari no Atelier"
    BasePattern = @(
        "Alchemist.*Marie.*Elie.*Futari.*no.*Atelier",
        "Alchemist.*Marie.*Elie",
        "Marie.*Elie.*Futari.*no.*Atelier",
        "마리.*에리.*사람.*아틀리에",
        "마리.*에리.*두.*사람",
        "마리.*에리",
        "두.*사람.*아틀리에",
        "Marie.*Elie",
        "Marie.*Futari.*Atelier",
        "Elie.*Futari.*Atelier"
    )
},

@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트 3"
    TargetPattern = "(K) Super Robot Taisen Compact 3"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*Super.*Robot.*Taisen.*Compact.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*슈퍼.*로봇.*대전.*콤팩트.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*슈퍼.*로봇.*대전.*콤펙트.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*슈퍼.*로봇.*대전.*컴팩트.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*슈퍼.*로봇.*대전.*컴펙트.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*슈퍼.*로봇.*대전.*3",
        "^(?!.*(?:(?<!\([^)]*?)(?:1|2|II|bu|dai))).*Super.*Robot.*Taisen.*Compact.*iii"
    )
},

@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트 원더스완 컬러"
    TargetPattern = "(K) Super Robot Taisen Compact for WonderSwan Color"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*Super.*Robot.*Taisen.*Compact.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤팩트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤펙트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴팩트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴펙트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤팩트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤펙트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴팩트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴펙트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤팩트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*콤펙트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴팩트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*컴펙트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈퍼.*로봇.*대전.*Compact.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*콤.*트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*컴.*트.*컬러",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*콤.*트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*컴.*트.*칼라",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*콤.*트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*슈로대.*컴.*트.*Color",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai))).*Super.*Robot.*Taisen.*Compact.*Color"
    )
}


)

# patched 폴더가 없으면 생성
if (-not (Test-Path "patched")) {
    New-Item -ItemType Directory -Path "patched"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./patched/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # Kor 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\patched\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -match '\(.*Kor.*?\)' -or $file.Name -match '\[.*Kor.*?\]')
                  }

    # Kor 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\patched\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to patched folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")