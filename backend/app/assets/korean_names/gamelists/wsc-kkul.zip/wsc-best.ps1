﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "마리 & 에리 - 두 사람의 아틀리에"
    TargetPattern = "Alchemist Marie & Elie - Futari no Atelier"
    BasePattern = @(
        "Alchemist.*Marie.*Elie.*Atelier",
        "Marie.*Elie.*Atelier",
        "Atelier.*Marie.*Elie"
    )
},
@{
    Name = "어나더 헤븐 - 그때의 기억"
    TargetPattern = "Another Heaven - Memory of those Days"
    BasePattern = @(
        "Another.*Heaven.*Memory.*Days",
        "Heaven.*Memory.*Days",
        "Memory.*Heaven.*Days"
    )
},
@{
    Name = "아크 더 래드 - 기신부활"
    TargetPattern = "Arc the Lad - Kishin Fukkatsu"
    BasePattern = @(
        "Arc.*Lad.*Kishin.*Fukkatsu",
        "Arc.*Lad.*Kishin",
        "Kishin.*Arc.*Lad"
    )
},
@{
    Name = "블루 윙 블리츠"
    TargetPattern = "Blue Wing Blitz"
    BasePattern = @(
        "Blue.*Wing.*Blitz",
        "Wing.*Blue.*Blitz",
        "Blitz.*Blue.*Wing"
    )
},
@{
    Name = "다크 아이즈 - 배틀 게이트"
    TargetPattern = "Dark Eyes - Battle Gate"
    BasePattern = @(
        "Dark.*Eyes.*Battle.*Gate",
        "Eyes.*Battle.*Gate",
        "Battle.*Dark.*Eyes"
    )
},

@{
    Name = "다이싱 나이트"
    TargetPattern = "Dicing Knight."
    BasePattern = @(
        "Dicing.*Knight",
        "Knight.*Dicing"
    )
},
@{
    Name = "디지몬 어드벤쳐 2 - D1 태머"
    TargetPattern = "Digimon Adventure 02 - D1 Tamers"
    BasePattern = @(
        "Digimon.*Adventure.*02.*D1.*Tamers",
        "Adventure.*02.*Digimon.*D1",
        "D1.*Tamers.*Digimon.*02"
    )
},
@{
    Name = "디지몬 - 양극 태머 & 음극 태머"
    TargetPattern = "Digimon Anode And Cathode Tamer"
    BasePattern = @(
        "Digimon.*Anode.*Cathode.*Tamer",
        "Anode.*Cathode.*Digimon.*Tamer",
        "Tamer.*Anode.*Cathode.*Digimon"
    )
},
@{
    Name = "디지몬 태머즈 - 배틀 스피릿 V 1.5"
    TargetPattern = "Digimon Tamers - Battle Spirit Ver. 1.5"
    BasePattern = @(
        "Digimon.*Tamers.*Battle.*Spirit.*Ver.*1.5",
        "Tamers.*Battle.*Spirit.*1.5.*Digimon",
        "Battle.*Spirit.*Tamers.*1.5.*Digimon"
    )
},
@{
    Name = "디지몬 태머즈 - 배틀 스피릿"
    TargetPattern = "Digimon Tamers - Battle Spirit"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:1.5|15))).*Digimon.*Tamers.*Battle.*Spirit",
        "^(?!.*(?:(?<!\([^)]*?)(?:1.5|15))).*Tamers.*Battle.*Spirit.*Digimon",
        "^(?!.*(?:(?<!\([^)]*?)(?:1.5|15))).*Battle.*Spirit.*Tamers.*Digimon"
    )
},
@{
    Name = "디지몬 태머즈 - 브레이브 태머"
    TargetPattern = "Digimon Tamers - Brave Tamer"
    BasePattern = @(
        "Digimon.*Tamers.*Brave.*Tamer",
        "Tamers.*Brave.*Tamer.*Digimon",
        "Brave.*Tamer.*Tamers.*Digimon"
    )
},
@{
    Name = "디지몬 태머즈 - 디지몬 메들리"
    TargetPattern = "Digimon Tamers - Digimon Medley"
    BasePattern = @(
        "Digimon.*Tamers.*Digimon.*Medley",
        "Tamers.*Digimon.*Medley.*Digimon",
        "Medley.*Tamers.*Digimon.*Digimon"
    )
},
@{
    Name = "디지털 몬스터 - D프로젝트"
    TargetPattern = "Digital Monster - D-Project"
    BasePattern = @(
        "Digital.*Monster.*D.*Project",
        "Monster.*D.*Project.*Digital",
        "D.*Project.*Digital.*Monster"
    )
},
@{
    Name = "디지털 몬스터 카드 게임 원더스완 컬러"
    TargetPattern = "Digital Monster Card Game - Ver. WonderSwan Color"
    BasePattern = @(
        "Digital.*Monster.*Card.*Game.*Wonder.*Swan.*Color",
        "Monster.*Card.*Game.*Digital.*Wonder.*Swan.*Color",
        "Card.*Game.*Monster.*Digital.*Wonder.*Swan.*Color"
    )
},
@{
    Name = "어디서나 햄스터 3"
    TargetPattern = "Dokodemo Hamster 3 - Odekake Saffron"
    BasePattern = @(
        "Dokodemo.*Hamster.*3.*Odekake.*Saffron",
        "Hamster.*Odekake.*Saffron.*3.*Dokodemo",
        "Odekake.*Saffron.*Dokodemo.*Hamster.*3"
    )
},

@{
    Name = "드래곤 볼"
    TargetPattern = "Dragon Ball"
    BasePattern = @(
        "Dragon.*Ball",
        "Ball.*Dragon"
    )
},
@{
    Name = "파이널 판타지 2"
    TargetPattern = "Final Fantasy II"
    BasePattern = @(
        "Final.*Fantasy.*II",
        "Final.*Fantasy.*2",
        "Fantasy.*II.*Final",
        "II.*Final.*Fantasy"
    )
},
@{
    Name = "파이널 판타지 4"
    TargetPattern = "Final Fantasy IV"
    BasePattern = @(
        "Final.*Fantasy.*IV",
        "Final.*Fantasy.*4",
        "Fantasy.*IV.*Final",
        "IV.*Final.*Fantasy"
    )
},
@{
    Name = "파이널 판타지"
    TargetPattern = "Final Fantasy"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|iv|4))).*Final.*Fantasy"
    )
},
@{
    Name = "파이널 랩 스페셜 - GT & 포뮬러 머신"
    TargetPattern = "Final Lap Special - GT & Formula Machine"
    BasePattern = @(
        "Final.*Lap.*Special.*GT.*Formula.*Machine",
        "Lap.*Special.*Formula.*Machine.*GT.*Final",
        "GT.*Formula.*Machine.*Final.*Lap.*Special"
    )
},
@{
    Name = "플래시 연인군"
    TargetPattern = "Flash Koibito-kun"
    BasePattern = @(
        "Flash.*Koibito.*kun",
        "Koibito.*kun.*Flash",
        "Kun.*Koibito.*Flash"
    )
},
@{
    Name = "TV 애니메이션 원피스 - 초파의 대모험"
    TargetPattern = "From TV Animation One Piece - Chopper no Daibouken"
    BasePattern = @(
        "From.*TV.*Animation.*One.*Piece.*Chopper.*no.*Daibouken",
        "One.*Piece.*Chopper.*Chopper",
        "Chopper.*Daibouken.*TV.*Animation.*One.*Piece"
    )
},
@{
    Name = "TV 애니메이션 원피스 - 그랜드 배틀 스완 콜로세움"
    TargetPattern = "From TV Animation One Piece - Grand Battle Swan Colosseum"
    BasePattern = @(
        "From.*TV.*Animation.*One.*Piece.*Grand.*Battle.*Swan.*Colosseum",
        "One.*Piece.*Grand.*Battle.*Swan.*Colosseum",
        "TV.*Animation.*Grand.*Battle.*Swan.*Colosseum.*One.*Piece",
        "Grand.*Battle.*Swan.*Colosseum.*TV.*Animation.*One.*Piece"
    )
},
@{
    Name = "TV 애니메이션 원피스 - 무지개 섬의 전설"
    TargetPattern = "From TV Animation One Piece - Niji no Shima Densetsu"
    BasePattern = @(
        "From.*TV.*Animation.*One.*Piece.*Niji.*no.*Shima.*Densetsu",
        "One.*Piece.*Niji.*Shima.*Densetsu",
        "Niji.*Shima.*Densetsu.*TV.*Animation.*One.*Piece"
    )
},
@{
    Name = "TV 애니메이션 원피스 - 트레져 워즈 2"
    TargetPattern = "From TV Animation One Piece - Treasure Wars 2 - Buggy Land e Youkoso"
    BasePattern = @(
        "From.*TV.*Animation.*One.*Piece.*Treasure.*Wars.*2.*Buggy.*Land.*Youkoso",
        "From.*TV.*Animation.*One.*Piece.*Treasure.*Wars.*2",
        "One.*Piece.*Treasure.*Wars.*Buggy.*Land.*Youkoso",
        "Treasure.*Wars.*2.*Buggy.*Land.*TV.*Animation.*One.*Piece"
    )
},

@{
    Name = "TV 애니메이션 원피스 - 트레져 워즈"
    TargetPattern = "From TV Animation One Piece - Treasure Wars"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|buggy))).*From.*TV.*Animation.*One.*Piece.*Treasure.*Wars",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|buggy))).*One.*Piece.*Treasure.*Wars",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|buggy))).*TV.*Animation.*Treasure.*Wars.*One.*Piece",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|buggy))).*Treasure.*Wars.*TV.*Animation.*One.*Piece"
    )
},
@{
    Name = "프론트 미션"
    TargetPattern = "Front Mission"
    BasePattern = @(
        "Front.*Mission",
        "Mission.*Front"
    )
},
@{
    Name = "격투! 크래시 기어 터보 - 기어 챔피언 리그"
    TargetPattern = "Gekitou! Crash Gear Turbo - Gear Champion League"
    BasePattern = @(
        "Gekitou.*Crash.*Gear.*Turbo.*Gear.*Champion.*League",
        "Crash.*Gear.*Turbo.*Champion.*League.*Gekitou",
        "Gear.*Champion.*League.*Crash.*Turbo.*Gekitou"
    )
},
@{
    Name = "환상마전 최유기 리트리뷰션 - 햇빛이 닿는 장소에서"
    TargetPattern = "Gensou Maden Saiyuuki Retribution - Hi no Ataru Basho de"
    BasePattern = @(
        "Gensou.*Maden.*Saiyuuki.*Retribution.*Hi.*no.*Ataru.*Basho.*de",
        "Saiyuuki.*Retribution.*Ataru.*Basho",
        "Maden.*Saiyuuki.*Hi.*Basho.*Gensou.*Retribution",
        "Saiyuuki.*Hi.*Basho.*Retribution.*Gensou.*Maden"
    )
},
@{
    Name = "황금 도끼 / 골든 엑스"
    TargetPattern = "Golden Axe"
    BasePattern = @(
        "Golden.*Axe",
        "Axe.*Golden"
    )
},

@{
    Name = "그랜스타 클로니클"
    TargetPattern = "Gransta Chronicle"
    BasePattern = @(
        "Gransta.*Chronicle",
        "Chronicle.*Gransta"
    )
},
@{
    Name = "길티 기어 피팃 2"
    TargetPattern = "Guilty Gear Petit 2"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:pet|petit))).*Guilty.*Gear.*Petit.*2",
        "^(?!.*(?:(?<!\([^)]*?)(?:pet|petit))).*Gear.*Petit.*2.*Guilty",
        "^(?!.*(?:(?<!\([^)]*?)(?:pet|petit))).*Petit.*2.*Guilty.*Gear"
    )
},
@{
    Name = "길티 기어 피팃"
    TargetPattern = "Guilty Gear Petit"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III))).*Guilty.*Gear.*Petit",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III))).*Gear.*Petit.*Guilty",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III))).*Petit.*Guilty.*Gear"
    )
},
@{
    Name = "건페이 EX"
    TargetPattern = "GunPey EX"
    BasePattern = @(
        "GunPey.*EX",
        "EX.*GunPey"
    )
},
@{
    Name = "반숙 영웅 - 아, 세계여 반숙이 되어라!!"
    TargetPattern = "Hanjuku Hero - Ah, Sekai yo Hanjuku Nare...!!"
    BasePattern = @(
        "Hanjuku.*Hero.*Ah.*Sekai.*yo.*Hanjuku.*Nare",
        "Hanjuku.*Hero.*Sekai.*Hanjuku.*Nare",
        "Hero.*Sekai.*Hanjuku.*Nare.*Ah.*yo",
        "Sekai.*Hanjuku.*Hero.*Ah.*yo.*Nare"
    )
},

@{
    Name = "움직이다 초코보"
    TargetPattern = "Hataraku Chocobo"
    BasePattern = @(
        "Hataraku.*Chocobo",
        "Chocobo.*Hataraku"
    )
},
@{
    Name = "헌터 X 헌터 - 그리드 아일랜드"
    TargetPattern = "Hunter X Hunter - Greed Island"
    BasePattern = @(
        "Hunter.*X.*Hunter.*Greed.*Island",
        "Hunter.*Hunter.*Greed.*Island",
        "X.*Hunter.*Greed.*Island.*Hunter",
        "Greed.*Island.*Hunter.*X.*Hunter"
    )
},
@{
    Name = "헌터 X 헌터 - 인도받는 자"
    TargetPattern = "Hunter X Hunter - Michibikareshi Mono"
    BasePattern = @(
        "Hunter.*X.*Hunter.*Michibikareshi.*Mono",
        "Hunter.*Hunter.*Michibi.*kareshi.*Mono",
        "X.*Hunter.*Michibikareshi.*Mono.*Hunter",
        "Michibikareshi.*Mono.*Hunter.*X.*Hunter"
    )
},
@{
    Name = "헌터 X 헌터 - 각자의 결의"
    TargetPattern = "Hunter X Hunter - Sorezore no Ketsui"
    BasePattern = @(
        "Hunter.*X.*Hunter.*Sorezore.*no.*Ketsui",
        "Hunter.*Hunter.*Sore.*zore.*Ketsui",
        "X.*Hunter.*Sorezore.*Ketsui.*Hunter",
        "Sorezore.*Ketsui.*Hunter.*X.*Hunter"
    )
},
@{
    Name = "이누야샤 - 풍운회권"
    TargetPattern = "Inuyasha - Fuuun Emaki"
    BasePattern = @(
        "Inuyasha.*Fuuun.*Emaki",
        "Inuyasha.*F.*un.*Emaki",
        "Fuuun.*Emaki.*Inuyasha",
        "Emaki.*Fuuun.*Inuyasha"
    )
},
@{
    Name = "이누야샤 - 카고메의 전국 일기"
    TargetPattern = "Inuyasha - Kagome no Sengoku Nikki"
    BasePattern = @(
        "Inuyasha.*Kagome.*no.*Sengoku.*Nikki",
        "Inuyasha.*Kagome.*Sengoku.*Nikki",
        "Sengoku.*Nikki.*Inuyasha.*Kagome"
    )
},
@{
    Name = "이누야샤 - 카고메의 꿈의 일기"
    TargetPattern = "Inuyasha - Kagome no Yume Nikki"
    BasePattern = @(
        "Inuyasha.*Kagome.*no.*Yume.*Nikki",
        "Inuyasha.*Kagome.*Yume.*Nikki",
        "Yume.*Nikki.*Inuyasha.*Kagome"
    )
},
@{
    Name = "저지먼트 실버소드 - 리버스 에디션"
    TargetPattern = "Judgement Silversword - Rebirth Edition"
    BasePattern = @(
        "Judgement.*Silversword.*Rebirth.*Edition",
        "Silversword.*Rebirth.*Edition.*Judgement",
        "Rebirth.*Edition.*Judgement.*Silversword"
    )
},
@{
    Name = "기동전사 건담 - 기렌의 야망 - 특별편 - 푸른별의 패자"
    TargetPattern = "Kidou Senshi Gundam - Giren no Yabou - Tokubetsu Hen - Aoki Hoshi no Hasha"
    BasePattern = @(
        "Kidou.*Senshi.*Gundam.*Giren.*no.*Yabou.*Tokubetsu.*Hen.*Aoki.*Hoshi.*no.*Hasha",
        "Gundam.*Giren.*Aoki.*Hoshi",
        "Gundam.*Yabou.*Tokubetsu.*Hen.*Aoki.*Hoshi.*Senshi.*Kidou"
    )
},
@{
    Name = "기동전사 건담 SEED"
    TargetPattern = "Kidou Senshi Gundam Seed"
    BasePattern = @(
        "Kidou.*Senshi.*Gundam.*Seed",
        "Senshi.*Gundam.*Seed",
        "Gundam.*Seed"
    )
},
@{
    Name = "기동전사 건담 Vol.1 - 사이드 7"
    TargetPattern = "Kidou Senshi Gundam Vol. 1 - Side 7"
    BasePattern = @(
        "Kidou.*Senshi.*Gundam.*Vol.*1.*Side.*7",
        "SGundam.*Side.*7.*Kidou",
        "Gundam.*Vol.*1.*Side.*7"
    )
},
@{
    Name = "기동전사 건담 Vol.2 - 자브로"
    TargetPattern = "Kidou Senshi Gundam Vol. 2 - Jaburo"
    BasePattern = @(
        "Kidou.*Senshi.*Gundam.*Vol.*2.*Jaburo",
        "Gundam.*Vol.*Jaburo.*Kidou",
        "Gundam.*Vol.*2.*Jaburo"
    )
},
@{
    Name = "기동전사 건담 Vol.3 - 아보아큐"
    TargetPattern = "Kidou Senshi Gundam Vol. 3 - A Baoa Qu"
    BasePattern = @(
        "Kidou.*Senshi.*Gundam.*Vol.*3.*A.*Baoa.*Qu",
        "Gundam.*Baoa.*Qu.*Kidou",
        "Gundam.*Vol.*3.*A.*Baoa.*Qu.*Kidou.*Senshi"
    )
},
@{
    Name = "근육맨 2세 - 초인성전사"
    TargetPattern = "Kinnikuman II-Sei - Choujin Seisenshi"
    BasePattern = @(
        "Kinnikuman.*II-Sei.*Choujin.*Seisenshi",
        "Kinnikuman.*Seisenshi.*Kinnikuman",
        "Choujin.*Seisenshi.*Kinnikuman.*II-Sei"
    )
},
@{
    Name = "근육맨 2세 - 드림 태그매치"
    TargetPattern = "Kinnikuman II-Sei - Dream Tag Match"
    BasePattern = @(
        "Kinnikuman.*II-Sei.*Dream.*Tag.*Match",
        "Kinnikuman.*Tag.*Match.*Kinnikuman",
        "Dream.*Tag.*Match.*Kinnikuman.*II-Sei"
    )
},
@{
    Name = "쿠루파라!"
    TargetPattern = "Kurupara!"
    BasePattern = @(
        "Kurupara"
    )
},

@{
    Name = "라스트 얼라이브"
    TargetPattern = "Last Alive"
    BasePattern = @(
        "Last.*Alive"
    )
},

@{
    Name = "마계탑사 사가"
    TargetPattern = "Makai Toushi Sa-Ga"
    BasePattern = @(
        "Makai.*Toushi.*Sa.*Ga"
    )
},

@{
    Name = "명탐정 코난 - 황혼의 황녀"
    TargetPattern = "Meitantei Conan - Yuugure No Koujo"
    BasePattern = @(
        "Meitantei.*Conan.*Yuugure.*Koujo",
        "Conan.*Yuugure.*Koujo"
    )
},

@{
    Name = "메모리즈 오프 - 페스타"
    TargetPattern = "Memories Off - Festa"
    BasePattern = @(
        "Memories.*Off.*Festa",
        "Memories.*Off"
    )
},

@{
    Name = "고양이 홈스 - 고스트 패닉"
    TargetPattern = "Mikeneko Holmes - Ghost Panic"
    BasePattern = @(
        "Mikeneko.*Holmes.*Ghost.*Panic",
        "Mikeneko.*Holmes"
    )
},

@{
    Name = "미스터 드릴러"
    TargetPattern = "Mr. Driller"
    BasePattern = @(
        "Mr.*Driller"
    )
},

@{
    Name = "남코 슈퍼 워즈"
    TargetPattern = "Namco Super Wars"
    BasePattern = @(
        "Namco.*Super.*Wars",
        "Super.*Wars"
    )
},

@{
    Name = "나루토 - 나뭇잎 인법체"
    TargetPattern = "Naruto - Konoha Ninpouchou"
    BasePattern = @(
        "Naruto.*Konoha.*Ninpouchou"
    )
},

@{
    Name = "포켓 속 도라에몽"
    TargetPattern = "Pocket no Naka no Doraemon"
    BasePattern = @(
        "Pocket.*no.*Naka.*no.*Doraemon",
        "Pocket.*Doraemon"
    )
},
@{
    Name = "락작"
    TargetPattern = "Raku Jongg"
    BasePattern = @(
        "Raku.*Jongg"
    )
},

@{
    Name = "리듬 라이더 케로리켄"
    TargetPattern = "Rhyme Rider Kerorican"
    BasePattern = @(
        "Rhyme.*Rider.*Kerorican"
    )
},

@{
    Name = "리비에라 - 약속의 땅 리비에라"
    TargetPattern = "Riviera - Yakusoku no Chi Riviera"
    BasePattern = @(
        "Riviera.*Yakusoku.*no.*Chi.*Riviera",
        "Riviera.*Yakusoku.*Riviera",
        "Riviera"
    )
},

@{
    Name = "록맨 에그제 - N1 배틀"
    TargetPattern = "Rockman EXE - N1 Battle"
    BasePattern = @(
        "Rock.*man.*EXE.*N1.*Battle"
    )
},

@{
    Name = "록맨 에그제 배틀 칩 GP"
    TargetPattern = "Rockman EXE WS"
    BasePattern = @(
        "Rock.*man.*EXE.*WS"
    )
},
@{
    Name = "로맨싱 사가"
    TargetPattern = "Romancing Sa-Ga"
    BasePattern = @(
        "Romancing.*Sa.*Ga"
    )
},

@{
    Name = "런딤 - 리턴 투 어스"
    TargetPattern = "RUN=DIM - Return to Earth"
    BasePattern = @(
        "RUN.*DIM.*Return.*to.*Earth",
        "RUN.*DIM",
        "Return.*to.*Earth"
    )
},

@{
    Name = "세인트 세이야 - 황금 전설편 - 퍼펙트 에디션"
    TargetPattern = "Saint Seiya - Ougon Densetsu Hen - Perfect Edition"
    BasePattern = @(
        "Saint.*Seiya.*Densetsu.*Hen.*Perfect.*Edition",
        "Seiya.*Ougon.*Densetsu.*Hen",
        "Saint.*Seiya.*Perfect.*Edition"
    )
},

@{
    Name = "SD 건담 - 오퍼레이션 UC"
    TargetPattern = "SD Gundam - Operation U.C."
    BasePattern = @(
        "SD.*Gundam.*Operation.*U.C."
    )
},

@{
    Name = "SD 건담 영웅전 - 기사 건담"
    TargetPattern = "SD Gundam Eiyuu Den - Kishi Densetsu"
    BasePattern = @(
        "SD.*Gundam.*Eiyuu.*Den.*Kishi.*Densetsu"
    )
},
@{
    Name = "SD 건담 영웅전 - 무사 건담"
    TargetPattern = "SD Gundam Eiyuu Den - Musha Densetsu"
    BasePattern = @(
        "SD.*Gundam.*Eiyuu.*Den.*Musha.*Densetsu"
    )
},

@{
    Name = "SD 건담 G 제너레이션 - 게더 비트 2"
    TargetPattern = "SD Gundam G Generation - Gather Beat 2"
    BasePattern = @(
        "SD.*Gundam.*G.*Generation.*Gather.*Beat.*2"
    )
},

@{
    Name = "SD 건담 G 제너레이션 - 모노아이 건담"
    TargetPattern = "SD Gundam G Generation - Mono-Eye Gundams"
    BasePattern = @(
        "SD.*Gundam.*G.*Generation.*Mono.*Eye.*Gundams"
    )
},

@{
    Name = "선계전 - TV 애니메이션 신계전 봉신연의"
    TargetPattern = "Senkaiden Ni - TV Animation Senkaiden Houshin Engi Yori"
    BasePattern = @(
        "Senkaiden.*Ni.*TV.*Animation.*Senkaiden.*Houshin.*Engi.*Yori",
        "Senkaiden",
        "TV.*Animation",
        "Houshin.*Engi"
    )
},

@{
    Name = "샤먼 킹 - 미래의 의지"
    TargetPattern = "Shaman King - Asu e no Ishi"
    BasePattern = @(
        "Shaman.*King.*Asu.*e.*no.*Ishi",
        "Shaman.*King",
        "Asu.*e.*no.*Ishi"
    )
},

@{
    Name = "주판하다"
    TargetPattern = "Sorobang"
    BasePattern = @(
        "Sorobang"
    )
},

@{
    Name = "스타 하트- 별과 대지의 사자"
    TargetPattern = "Star Hearts - Hoshi to Daichi no Shisha"
    BasePattern = @(
        "Star.*Hearts.*Hoshi.*to.*Daichi.*no.*Shisha",
        "Star.*Hearts",
        "Hoshi.*to.*Daichi.*no.*Shisha"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트 3"
    TargetPattern = "Super Robot Taisen Compact 3"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*3"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트 원더스완 컬러"
    TargetPattern = "Super Robot Taisen Compact for WonderSwan Color"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*for.*Wonder.*Swan.*Color"
    )
},

@{
    Name = "테러 2"
    TargetPattern = "Terrors 2"
    BasePattern = @(
        "Terrors.*2"
    )
},
@{
    Name = "테트리스"
    TargetPattern = "Tetris"
    BasePattern = @(
        "Tetris"
    )
},


@{
    Name = "우주 전함 야마토"
    TargetPattern = "Uchuu Senkan Yamato"
    BasePattern = @(
        "Uchuu.*Senkan.*Yamato",
        "Uchuu",
        "Senkan.*Yamato"
    )
},

@{
    Name = "울트라맨 - 빛의 나라의 사자"
    TargetPattern = "Ultraman - Hikari no Kuni no Shisha"
    BasePattern = @(
        "Ultraman.*Hikari.*no.*Kuni.*no.*Shisha",
        "Ultraman",
        "Hikari.*no.*Kuni.*no.*Shisha"
    )
},

@{
    Name = "와일드 카드"
    TargetPattern = "Wild Card"
    BasePattern = @(
        "Wild.*Card"
    )
},

@{
    Name = "위드 유 - 바라보고 싶어"
    TargetPattern = "With You - Mitsumete Itai"
    BasePattern = @(
        "With.*You.*Mitsumete.*Itai",
        "With.*You",
        "Mitsumete.*Itai"
    )
},

@{
    Name = "위저드라 시나리오1 - 광란의 시련"
    TargetPattern = "Wizardry Scenario 1 - Proving Grounds of the Mad Overlord"
    BasePattern = @(
        "Wizardry.*Scenario.*1.*Proving.*Grounds.*of.*the.*Mad.*Overlord",
        "Wizardry.*Scenario.*1",
        "Proving.*Grounds.*of.*the.*Mad.*Overlord"
    )
},

@{
    Name = "원더 클래식"
    TargetPattern = "Wonder Classic"
    BasePattern = @(
        "Wonder.*Classic"
    )
},

@{
    Name = "X - 카드 오브 페이트"
    TargetPattern = "X - Card of Fate"
    BasePattern = @(
        "X.*Card.*Fate",
        "Card.*Fate"
    )
},

@{
    Name = "사이 리틀"
    TargetPattern = "XI Little"
    BasePattern = @(
        "XI.*Little"
    )
}


)

# best 폴더가 없으면 생성
if (-not (Test-Path "best")) {
    New-Item -ItemType Directory -Path "best"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

    # 먼저 이미 처리된 파일이 있는지 확인
    $zipFilePath = "./best/" + $game.TargetPattern + ".zip"
    if (Test-Path $zipFilePath) {
        Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
        Write-Host '------------------------'
        continue
    }

    # USA 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\best\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외    
                      ($game.BasePattern | Where-Object { 
                          # 괄호 안의 숫자들만 제거하고 다른 문자는 유지
                          $tempName = $file.Name -replace '\(([^)]*)\)', {
                              param($match)
                              '(' + ($match.Groups[1].Value -replace '\d', '') + ')'
                          }
                          $tempName -match $_
                      }) -and 
                      ($file.Name -match '\(.*USA.*?\)' -or $file.Name -match '\[.*USA.*?\]')
                  }

    # USA 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\best\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외    
                         ($game.BasePattern | Where-Object { 
                             # 괄호 안의 숫자들만 제거하고 다른 문자는 유지
                             $tempName = $file.Name -replace '\(([^)]*)\)', {
                                 param($match)
                                 '(' + ($match.Groups[1].Value -replace '\d', '') + ')'
                             }
                             $tempName -match $_
                         })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to best folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")