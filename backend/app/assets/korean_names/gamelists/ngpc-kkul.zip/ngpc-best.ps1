﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "빅 뱅 프로 레슬링"
    TargetPattern = "Baseball Stars Color"
    BasePattern = @(
        "Baseball.*Stars.*Color",
        "Stars.*Baseball.*Color",
        "Color.*Baseball.*Stars"
    )
},

@{
    Name = "바이오모터 유니트론"
    TargetPattern = "Big Bang Pro Wrestling"
    BasePattern = @(
        "Big.*Bang.*Pro.*Wrestling",
        "Pro.*Wrestling.*Big.*Bang",
        "Wrestling.*Big.*Bang.*Pro"
    )
},
@{
    Name = "비쿠리맨 2000 - 비바! 포켓 페스티벌"
    TargetPattern = "Bikkuriman 2000 Viva!"
    BasePattern = @(
        "Bikkuriman.*2000.*Viva",
        "2000.*Bikkuriman.*Viva",
        "Viva.*Bikkuriman.*2000"
    )
},

@{
    Name = "바이오모터 유니트론"
    TargetPattern = "Biomotor Unitron"
    BasePattern = @(
        "Biomotor.*Unitron",
        "Unitron.*Biomotor"
    )
},
@{
    Name = "버스트 어 무브 포켓"
    TargetPattern = "Bust-A-Move Pocket"
    BasePattern = @(
        "Bust.*A.*Move.*Pocket",
        "Move.*Bust.*A.*Pocket",
        "Pocket.*Bust.*A.*Move"
    )
},

@{
    Name = "쿨 보더스 포켓"
    TargetPattern = "Cool Boarders Pocket"
    BasePattern = @(
        "Cool.*Boarders.*Pocket",
        "Boarders.*Cool.*Pocket",
        "Pocket.*Cool.*Boarders"
    )
},

@{
    Name = "쿨쿨 잼"
    TargetPattern = "Cool Cool Jam"
    BasePattern = @(
        "Cool.*Cool.*Jam",
        "Jam.*Cool.*Cool"
    )
},
@{
    Name = "크러쉬 롤러"
    TargetPattern = "Crush Roller"
    BasePattern = @(
        "Crush.*Roller",
        "Roller.*Crush"
    )
},

@{
    Name = "다크 암즈 - 비스트 버스터 1999"
    TargetPattern = "Dark Arms - Beast Buster 1999"
    BasePattern = @(
        "Dark.*Arms.*Beast.*Buster.*1999",
        "Beast.*Buster.*Dark.*Arms.*1999",
        "1999.*Dark.*Arms.*Beast.*Buster"
    )
},

@{
    Name = "델타 워프"
    TargetPattern = "Delta Warp"
    BasePattern = @(
        "Delta.*Warp",
        "Warp.*Delta"
    )
},
@{
    Name = "전설의 오우거 배틀 외전 - 제노비아의 왕자"
    TargetPattern = "Densetsu no Ogre Battle Gaiden - Zenobia no Ouji"
    BasePattern = @(
        "Densetsu.*Ogre.*Battle.*Gaiden.*Zenobia.*Ouji",
        "Ogre.*Battle.*Densetsu.*Gaiden.*Zenobia.*Ouji",
        "Zenobia.*Ouji.*Densetsu.*Ogre.*Battle.*Gaiden"
    )
},

@{
    Name = "전차로 고! 2 네오지오 포켓"
    TargetPattern = "Densha de GO! 2"
    BasePattern = @(
        "Densha.*de.*GO.*2",
        "GO.*2.*Densha.*de",
        "2.*Densha.*de.*GO"
    )
},

@{
    Name = "다이브 얼러트 - 번 편"
    TargetPattern = "Dive Alert - Burn Hen"
    BasePattern = @(
        "Dive.*Alert.*Burn.*Hen",
        "Burn.*Hen.*Dive.*Alert",
        "Alert.*Dive.*Burn.*Hen"
    )
},

@{
    Name = "다이브 얼러트 - 레베카 편"
    TargetPattern = "Dive Alert - Rebecca Hen"
    BasePattern = @(
        "Dive.*Alert.*Rebecca.*Hen",
        "Rebecca.*Hen.*Dive.*Alert",
        "Alert.*Dive.*Rebecca.*Hen"
    )
},

@{
    Name = "다이너마이트 슬러거"
    TargetPattern = "Dynamite Slugger"
    BasePattern = @(
        "Dynamite.*Slugger",
        "Slugger.*Dynamite"
    )
},

@{
    Name = "신기세기 에볼루션 - 끝이 없는 던전"
    TargetPattern = "Evolution - Eternal Dungeon"
    BasePattern = @(
        "Evolution.*Eternal.*Dungeon",
        "Eternal.*Dungeon.*Evolution",
        "Dungeon.*Evolution.*Eternal"
    )
},
@{
    Name = "판타스틱 나이트 드림 - 코튼"
    TargetPattern = "Fantastic Night Dreams - Cotton"
    BasePattern = @(
        "Fantastic.*Night.*Dreams.*Cotton",
        "Night.*Dreams.*Fantastic.*Cotton",
        "Cotton.*Fantastic.*Night.*Dreams"
    )
},

@{
    Name = "파셀레이"
    TargetPattern = "Faselei!"
    BasePattern = @(
        "Faselei",
        "Faselei!"
    )
},

@{
    Name = "아랑전설 F-콘택트 - 포켓 파이팅 시리즈"
    TargetPattern = "Fatal Fury - F-Contact"
    BasePattern = @(
        "Fatal.*Fury.*F.*Contact",
        "F.*Contact.*Fatal.*Fury",
        "Fury.*Fatal.*F.*Contact"
    )
},
@{
    Name = "힘내라 네오 포케군"
    TargetPattern = "Ganbare Neo Poke Kun"
    BasePattern = @(
        "Ganbare.*Neo.*Poke.*Kun",
        "Neo.*Poke.*Ganbare.*Kun",
        "Poke.*Kun.*Ganbare.*Neo"
    )
},

@{
    Name = "인피니티 큐어"
    TargetPattern = "Infinity Cure"
    BasePattern = @(
        "Infinity.*Cure",
        "Cure.*Infinity"
    )
},

@{
    Name = "기갑세기 유니트론 - 빛나는 땅에서"
    TargetPattern = "Kikou Seiki Unitron"
    BasePattern = @(
        "Kikou.*Seiki.*Unitron",
        "Seiki.*Unitron.*Kikou",
        "Unitron.*Kikou.*Seiki"
    )
},

@{
    Name = "킹 오브 파이터즈 R-2 - 포켓 파이팅 시리즈"
    TargetPattern = "King of Fighters R-2"
    BasePattern = @(
        "King.*Fighters.*R-2",
        "Fighters.*King.*R-2",
        "R-2.*King.*Fighters"
    )
},
@{
    Name = "월하의 검사 - 운명 너머"
    TargetPattern = "Last Blade - Beyond The Destiny"
    BasePattern = @(
        "Last.*Blade.*Beyond.*Destiny",
        "Blade.*Last.*Destiny",
        "Destiny.*Blade.*Last"
    )
},
@{
    Name = "매지컬 드롭 포켓"
    TargetPattern = "Magical Drop Pocket"
    BasePattern = @(
        "Magical.*Drop.*Pocket",
        "Drop.*Magical.*Pocket",
        "Pocket.*Magical.*Drop"
    )
},

@{
    Name = "메모리즈 오프 - 퓨어"
    TargetPattern = "Memories Off - Pure"
    BasePattern = @(
        "Memories.*Off.*Pure",
        "Off.*Memories.*Pure",
        "Pure.*Memories.*Off"
    )
},
@{
    Name = "메탈 슬러그 - 첫 번째 미션"
    TargetPattern = "Metal Slug - 1st Mission"
    BasePattern = @(
        "Metal.*Slug.*1st.*Mission",
        "Slug.*Metal.*1st.*Mission",
        "1st.*Metal.*Slug.*Mission"
    )
},
@{
    Name = "메탈 슬러그 - 두 번째 미션"
    TargetPattern = "Metal Slug - 2nd Mission"
    BasePattern = @(
        "Metal.*Slug.*2nd.*Mission",
        "Slug.*Metal.*2nd.*Mission",
        "2nd.*Metal.*Slug.*Mission"
    )
},

@{
    Name = "미즈키 시게루의 요괴사진관"
    TargetPattern = "Mizuki Shigeru no Youkai Shashinkan"
    BasePattern = @(
        "Mizuki.*Shigeru.*Youkai.*Shashinkan",
        "Shigeru.*Mizuki.*Youkai.*Shashinkan",
        "Youkai.*Shashinkan.*Mizuki.*Shigeru"
    )
},
@{
    Name = "네오 포케 프로 야구"
    TargetPattern = "Neo Poke Pro Yakyuu"
    BasePattern = @(
        "Neo.*Poke.*Pro.*Yakyuu",
        "Poke.*Neo.*Pro.*Yakyuu",
        "Yakyuu.*Neo.*Poke.*Pro"
    )
},
@{
    Name = "네오 터프 마스터즈"
    TargetPattern = "Neo Turf Masters"
    BasePattern = @(
        "Neo.*Turf.*Masters",
        "Turf.*Neo.*Masters",
        "Masters.*Neo.*Turf"
    )
},
@{
    Name = "네오지오컵 98 플러스 컬러 - 포켓 스포츠 시리즈"
    TargetPattern = "NeoGeo Cup '98 Plus"
    BasePattern = @(
        "Neo.*Geo.*Cup.*98.*Plus",
        "Neo.*Geo.*98.*Plus.*Cup",
        "98.*Plus.*Neo.*Geo.*Cup"
    )
},
@{
    Name = "니게론파"
    TargetPattern = "Nige-ron-pa"
    BasePattern = @(
        "Nige.*ron.*pa",
        "Nigeronpa"
    )
},
@{
    Name = "픽쳐 퍼즐"
    TargetPattern = "Oekaki Pazuru"
    BasePattern = @(
        "Oekaki.*Pazuru",
        "Oekaki.*Puzzle",
        "Puzzle.*Oekaki",
        "Pazuru.*Oekaki"
    )
},

@{
    Name = "팩맨"
    TargetPattern = "Pac-Man"
    BasePattern = @(
        "Pac.*Man",
        "Man.*Pac"
    )
},
@{
    Name = "파티 메일"
    TargetPattern = "Party Mail"
    BasePattern = @(
        "Party.*Mail",
        "Mail.*Party"
    )
},
@{
    Name = "포켓 러브 - if"
    TargetPattern = "Pocket Love - If"
    BasePattern = @(
        "Pocket.*Love.*If",
        "Love.*Pocket.*If",
        "If.*Pocket.*Love"
    )
},

@{
    Name = "포켓 테니스 컬러 - 포켓 스포츠 시리즈"
    TargetPattern = "Pocket Tennis Color - Pocket Sports Series"
    BasePattern = @(
        "Pocket.*Tennis.*Color.*Pocket.*Sports.*Series",
        "Tennis.*Pocket.*Color.*Pocket.*Sports.*Series",
        "Color.*Pocket.*Tennis.*Pocket.*Sports.*Series"
    )
},
@{
    Name = "뿌요 팝"
    TargetPattern = "Puyo Puyo 2"
    BasePattern = @(
        "Puyo.*Pop",
        "Puyo.*Puyo.*2",
        "Puyo.*2.*Puyo",
        "2.*Puyo.*Puyo"
    )
},
@{
    Name = "연결 퍼즐 연결해서 퐁! 컬러"
    TargetPattern = "Renketsu Puzzle Tsunagete Pon!"
    BasePattern = @(
        "Renketsu.*Puzzle.*Tsunagete.*Pon",
        "Puzzle.*Renketsu.*Tsunagete.*Pon",
        "Tsunagete.*Pon.*Renketsu.*Puzzle"
    )
},
@{
    Name = "록맨 - 배틀 엔 파이터즈"
    TargetPattern = "Rockman - Battle & Fighters"
    BasePattern = @(
        "Rockman.*Battle.*Fighters",
        "Battle.*Rockman.*Fighters",
        "Fighters.*Rockman.*Battle"
    )
},
@{
    Name = "사무라이 쇼다운! 2 - 포켓 파이팅 시리즈"
    TargetPattern = "Samurai Shodown! 2 - Pocket Fighting Series"
    BasePattern = @(
        "Samurai.*Shodown.*2.*Pocket.*Fighting.*Series",
        "Shodown.*Samurai.*2.*Pocket.*Fighting.*Series",
        "2.*Samurai.*Shodown.*Pocket.*Fighting.*Series"
    )
},
@{
    Name = "SNK 걸즈 파이터"
    TargetPattern = "SNK Gals Fighters"
    BasePattern = @(
        "SNK.*Gals.*Fighters",
        "Gals.*SNK.*Fighters",
        "Fighters.*SNK.*Gals"
    )
},

@{
    Name = "SNK vs 캡콤 - 카드 파이터 2 - 익스펜드 에디션"
    TargetPattern = "SNK vs. Capcom - Card Fighters 2 Expand Edition"
    BasePattern = @(
        "SNK.*vs.*Capcom.*Card.*Fighters.*2.*Expand.*Edition",
        "Capcom.*vs.*SNK.*Card.*Fighters.*2.*Expand.*Edition",
        "Card.*Fighters.*2.*SNK.*vs.*Capcom.*Expand.*Edition"
    )
},
@{
    Name = "SNK vs 캡콤 - 격돌 카드 파이터 - 캡콤 서포터 버전"
    TargetPattern = "SNK vs. Capcom - Card Fighters Clash - Capcom Version"
    BasePattern = @(
        "SNK.*vs.*Capcom.*Card.*Fighters.*Clash.*Capcom.*Version",
        "Capcom.*vs.*SNK.*Card.*Fighters.*Clash.*Capcom.*Version",
        "Card.*Fighters.*Clash.*SNK.*vs.*Capcom.*Capcom.*Version"
    )
},
@{
    Name = "SNK vs 캡콤 - 격돌 카드 파이터 - SNK 서포터 버전"
    TargetPattern = "SNK vs. Capcom - Card Fighter's Clash - SNK Version"
    BasePattern = @(
        "SNK.*vs.*Capcom.*Card.*Fighter's.*Clash.*SNK.*Version",
        "SNK.*vs.*Capcom.*Card.*Fighters.*Clash.*SNK.*Version",
        "Card.*Fighters.*Clash.*SNK.*vs.*Capcom.*SNK.*Version"
    )
},
@{
    Name = "SNK vs 캡콤 - 밀레니엄 매치"
    TargetPattern = "SNK vs. Capcom - The Match of the Millennium"
    BasePattern = @(
        "SNK.*vs.*Capcom.*The.*Match.*of.*the.*Millennium",
        "Capcom.*vs.*SNK.*The.*Match.*of.*the.*Millennium",
        "The.*Match.*of.*the.*Millennium.*SNK.*vs.*Capcom"
    )
},
@{
    Name = "소닉 더 헤지혹 - 포켓 어드벤처"
    TargetPattern = "Sonic the Hedgehog - Pocket Adventure"
    BasePattern = @(
        "Sonic.*the.*Hedgehog.*Pocket.*Adventure",
        "Hedgehog.*Sonic.*the.*Pocket.*Adventure",
        "Pocket.*Adventure.*Sonic.*the.*Hedgehog"
    )
},
@{
    Name = "킹 오브 파이터즈 - 배틀로 파라다이스"
    TargetPattern = "The King of Fighters - Battle de Paradise"
    BasePattern = @(
        "The.*King.*of.*Fighters.*Battle.*de.*Paradise",
        "King.*of.*Fighters.*Battle.*de.*Paradise",
        "Battle.*de.*Paradise.*The.*King.*of.*Fighters"
    )
},
@{
    Name = "이어터져 퐁! 2"
    TargetPattern = "Tsunagete Pon! 2"
    BasePattern = @(
        "Tsunagete.*Pon.*2",
        "Pon.*Tsunagete.*2",
        "2.*Tsunagete.*Pon"
    )
}



)

# best 폴더가 없으면 생성
if (-not (Test-Path "best")) {
    New-Item -ItemType Directory -Path "best"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./best/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # Kor 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\best\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외     
                      ($file.Name -match '\(.*Kor.*?\)' -or $file.Name -match '\[.*Kor.*?\]')
                  }

    # Kor 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\best\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외    
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to best folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")