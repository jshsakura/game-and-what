﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "(K) SNK vs 캡콤 - 밀레니엄 매치, 정상결전 최강 파이터즈 - SNK VS CAPCOM"
    TargetPattern = "(K) SNK vs. Capcom - The Match of the Millennium"
    BasePattern = @(
        "SNK.*vs.*Capcom.*The.*밀레니엄.*매치",
        "SNK.*vs.*Capcom.*The.*밀레니엄.*매치",
        "정상.*결전",
        "최강.*파이터즈",
        "SNK.*vs.*Capcom.*The.*Match.*of.*the.*Millennium",
        "Capcom.*vs.*SNK.*The.*Match.*of.*the.*Millennium",
        "The.*Match.*Millennium.*SNK.*vs.*Capcom"
    )
},

@{
    Name = "(K) SNK 걸즈 파이터"
    TargetPattern = "(K) SNK Gals Fighters"
    BasePattern = @(
        "SNK.*Gals.*Fighters",
        "SNK.*Gal.*Fighter",
        "Gal.*Fighter",
        "girl.*Fighter",
        "SNK.*걸즈.*파이터",
        "SNK.*갈.*파이터",
        "SNK.*걸.*파이터",
        "SNK.*갈.*Fighter",
        "SNK.*걸.*Fighter",
        "갈.*파이터",
        "걸.*파이터",
        "갈.*Fighter",
        "걸.*Fighter",
        "SNK.*갈즈.*파이터"
    )
},

@{
    Name = "SNK vs 캡콤 - 카드 파이터 2 - 익스펜드 에디션"
    TargetPattern = "SNK vs. Capcom - Card Fighters 2 Expand Edition"
    BasePattern = @(
        "SNK.*vs.*Capcom.*Card.*Fighters.*2.*Expand.*Edition",
        "SNK.*캡콤.*카드.*파이터.*2.*익스펜드.*에디션",
        "캡콤.*카드.*파이터.*2.*익스팬드.*에디션",
        "카드.*파이터.*2.*익스펜드.*에디션",
        "카드.*파이터.*2.*익스.*드.*에디션",
        "SNK.*Card.*Fighters.*2.*Expand.*Edition",
        "Card.*Fighters.*2.*Expand.*Edition",
        "SNK.*vs.*캡콤.*Card.*Fighters.*2.*Expand.*Edition",
        "Card.*Fighters.*2.*SNK.*vs.*Capcom.*Expand.*Edition"
    )
}

)

# patched 폴더가 없으면 생성
if (-not (Test-Path "patched")) {
    New-Item -ItemType Directory -Path "patched"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./patched/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # Kor 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\patched\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -match '\(.*Kor.*?\)' -or $file.Name -match '\[.*Kor.*?\]')
                  }

    # Kor 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\patched\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to patched folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")