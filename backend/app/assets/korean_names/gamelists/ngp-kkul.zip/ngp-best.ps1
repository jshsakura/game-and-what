﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "베이스볼 스타즈 - 포켓 스포츠 시리즈"
    TargetPattern = "Baseball Stars"
    BasePattern = @(
        "Baseball.*Stars",
        "Stars.*Baseball"
    )
},

@{
    Name = "킹 오브 파이터즈 R-1 - 포켓 파이팅 시리즈"
    TargetPattern = "King Of Fighters R-1"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*King.*Of.*Fighters.*R.*1",
        "^(?!.*(?:2|3|II|III)).*Fighters.*King.*Of.*R.*1",
        "^(?!.*(?:2|3|II|III)).*R.*1.*King.*Of.*Fighters"
    )
},

@{
    Name = "메론짱의 성장일기"
    TargetPattern = "Melon-chan no Seichouki"
    BasePattern = @(
        "Melon.*chan.*Seichouki",
        "Seichouki.*Melon.*chan"
    )
},

@{
    Name = "네오지오 컵 98"
    TargetPattern = "NeoGeo Cup '98"
    BasePattern = @(
        "Neo.*Geo.*Cup.*98",
        "Cup.*Neo.*Geo.*98",
        "98.*Neo.*Geo.*Cup"
    )
},


@{
    Name = "포켓 테니스 - 포켓 스포츠 시리즈"
    TargetPattern = "Pocket Tennis"
    BasePattern = @(
        "Pocket.*Tennis",
        "Tennis.*Pocket"
    )
},

@{
    Name = "연결 퍼즐 연결해서 퐁!"
    TargetPattern = "Renketsu Puzzle Tsunagete Pon!"
    BasePattern = @(
        "Renketsu.*Puzzle.*Tsunagete.*Pon",
        "Puzzle.*Renketsu.*Tsunagete.*Pon",
        "Tsunagete.*Pon.*Renketsu.*Puzzle"
    )
},

@{
    Name = "사무라이 쇼다운! - 포켓 파이팅 시리즈"
    TargetPattern = "Samurai Spirits!"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*Samurai.*Spirits",
        "^(?!.*(?:2|3|II|III)).*Samurai.*Shodown",
        "^(?!.*(?:2|3|II|III)).*Shodown.*Samurai",
        "^(?!.*(?:2|3|II|III)).*Spirits.*Samurai"
    )
}



)

# best 폴더가 없으면 생성
if (-not (Test-Path "best")) {
    New-Item -ItemType Directory -Path "best"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./best/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # Kor 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\best\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -match '\(.*Kor.*?\)' -or $file.Name -match '\[.*Kor.*?\]')
                  }

    # Kor 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\best\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to best folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")