﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(

@{
    Name = "앵커즈 필드"
    TargetPattern = "Anchorz Field"
    BasePattern = @(
        "Anchorz.*Field",
        "Field.*Anchorz"
    )
},
@{
    Name = "아머드 유닛"
    TargetPattern = "Armored Unit"
    BasePattern = @(
        "Armored.*Unit",
        "Unit.*Armored"
    )
},
@{
    Name = "폭주 데코트라 전설 원더스완"
    TargetPattern = "Bakusou Dekotora Densetsu for WonderSwan"
    BasePattern = @(
        "Bakusou.*Dekotora.*Densetsu.*Wonder.*Swan",
        "Dekotora.*Bakusou.*Wonder.*Swan",
        "Wonder.*Swan.*Densetsu.*Bakusou"
    )
},
@{
    Name = "비트매니아 원더스완"
    TargetPattern = "beat mania for WonderSwan"
    BasePattern = @(
        "beat.*mania.*Wonder.*Swan",
        "mania.*beat.*Wonder.*Swan",
        "Wonder.*Swan.*beat.*mania"
    )
},
@{
    Name = "버퍼즈 에볼루션"
    TargetPattern = "Buffers Evolution"
    BasePattern = @(
        "Buffers.*Evolution",
        "Evolution.*Buffers"
    )
},

@{
    Name = "카드캡터 사쿠라 - 사쿠라와 이상한 크로카드"
    TargetPattern = "Cardcaptor Sakura - Sakura to Fushigi na Clow Card"
    BasePattern = @(
        "Cardcaptor.*Sakura.*Fushigi.*Clow.*Card",
        "Sakura.*Clow.*Fushigi.*Cardcaptor",
        "Clow.*Card.*Sakura.*Fushigi"
    )
},
@{
    Name = "카오스 기어 - 인도받는 자"
    TargetPattern = "Chaos Gear - Michibikareshi Mono"
    BasePattern = @(
        "Chaos.*Gear.*Michibikareshi.*Mono",
        "Michibikareshi.*Chaos.*Gear",
        "Gear.*Mono.*Chaos"
    )
},
@{
    Name = "초코보의 신기한 던전 원더스완"
    TargetPattern = "Chocobo no Fushigi na Dungeon for WonderSwan"
    BasePattern = @(
        "Chocobo.*Fushigi.*Dungeon.*Wonder.*Swan",
        "Fushigi.*Chocobo.*Wonder.*Swan",
        "Wonder.*Swan.*Chocobo.*Dungeon"
    )
},
@{
    Name = "초형귀 - 남자의혼찰"
    TargetPattern = "Chou Aniki - Otoko no Tamafuda"
    BasePattern = @(
        "Chou.*Aniki.*Otoko.*Tamafuda",
        "Otoko.*Chou.*Tamafuda",
        "Tamafuda.*Aniki.*Otoko"
    )
},
@{
    Name = "초전기 카드배틀 - 요부 마계"
    TargetPattern = "Chou Denki Card Battle - Youfu Makai"
    BasePattern = @(
        "Chou.*Denki.*Card.*Battle.*Youfu.*Makai",
        "Denki.*Card.*Makai.*Chou",
        "Makai.*Battle.*Denki.*Card"
    )
},

@{
    Name = "클락 타워 원더스완"
    TargetPattern = "Clock Tower for WonderSwan"
    BasePattern = @(
        "Clock.*Tower.*Wonder.*Swan",
        "Tower.*Clock.*Wonder.*Swan",
        "Wonder.*Swan.*Clock.*Tower"
    )
},
@{
    Name = "크레이지 클라이머"
    TargetPattern = "Crazy Climber"
    BasePattern = @(
        "Crazy.*Climber",
        "Climber.*Crazy"
    )
},
@{
    Name = "전차로 고! 2"
    TargetPattern = "Densha de Go! 2"
    BasePattern = @(
        "Densha.*Go.*2",
        "Go.*Densha.*2",
        "2.*Go.*Densha"
    )
},
@{
    Name = "전차로 고!"
    TargetPattern = "Densha de Go!"
    BasePattern = @(
        "Densha.*Go",
        "Go.*Densha"
    )
},
@{
    Name = "디지몬 ver. 원더스완"
    TargetPattern = "Digimon - Ver. WonderSwan"
    BasePattern = @(
        "Digimon.*Ver.*Wonder.*Swan",
        "Ver.*Digimon.*Wonder.*Swan",
        "Wonder.*Swan.*Digimon.*Ver"
    )
},

@{
    Name = "디지몬 어드벤쳐 - 양극 태머"
    TargetPattern = "Digimon Adventure - Anode Tamer"
    BasePattern = @(
        "Digimon.*Adventure.*Anode.*Tamer",
        "Anode.*Digimon.*Tamer.*Adventure",
        "Tamer.*Adventure.*Anode.*Digimon"
    )
},
@{
    Name = "디지몬 어드벤쳐 - 음극 태머"
    TargetPattern = "Digimon Adventure - Cathode Tamer"
    BasePattern = @(
        "Digimon.*Adventure.*Cathode.*Tamer",
        "Cathode.*Digimon.*Tamer.*Adventure",
        "Tamer.*Adventure.*Cathode.*Digimon"
    )
},
@{
    Name = "디지몬 어드벤쳐 2 - 태그 태머"
    TargetPattern = "Digimon Adventure 02 - Tag Tamers"
    BasePattern = @(
        "Digimon.*Adventure.*02.*Tag.*Tamers",
        "Adventure.*02.*Digimon.*Tamers",
        "Tamers.*02.*Adventure.*Digimon"
    )
},
@{
    Name = "디지털 파트너"
    TargetPattern = "Digital Partner"
    BasePattern = @(
        "Digital.*Partner",
        "Partner.*Digital"
    )
},
@{
    Name = "어디서나 햄스터"
    TargetPattern = "Dokodemo Hamster"
    BasePattern = @(
        "Dokodemo.*Hamster",
        "Hamster.*Dokodemo"
    )
},
@{
    Name = "D의 게라지 21 공모 게임 - 씨를 뿌리는 새"
    TargetPattern = "D's Garage 21 Koubo Game - Tane o Maku Tori"
    BasePattern = @(
        "D.*Garage.*21.*Koubo.*Game.*Tane.*Maku.*Tori",
        "Garage.*Tane.*21.*Maku.*Tori",
        "Tori.*Game.*Garage.*21"
    )
},
@{
    Name = "피버 - 산쿄 공식 파칭코 시뮬레이션"
    TargetPattern = "Engacho! for WonderSwan"
    BasePattern = @(
        "Engacho.*WonderSwan",
        "WonderSwan.*Engacho"
    )
},
@{
    Name = "인가초 원더스완"
    TargetPattern = "Fever - Sankyo Koushiki Pachinko Simulation for WonderSwan"
    BasePattern = @(
        "Fever.*Sankyo.*Koushiki.*Pachinko.*Simulation.*Wonder.*Swan",
        "Sankyo.*Pachinko.*Fever.*Wonder.*Swan",
        "Wonder.*Swan.*Simulation.*Fever"
    )
},
@{
    Name = "파이널 랩 2000"
    TargetPattern = "Final Lap 2000"
    BasePattern = @(
        "Final.*Lap.*2000",
        "Lap.*Final.*2000",
        "2000.*Final.*Lap"
    )
},
@{
    Name = "파이어 프로 레슬링 원더스완"
    TargetPattern = "Fire Pro Wrestling for WonderSwan"
    BasePattern = @(
        "Fire.*Pro.*Wrestling.*Wonder.*Swan",
        "Pro.*Wrestling.*Fire.*Wonder.*Swan",
        "Wonder.*Swan.*Fire.*Pro"
    )
},
@{
    Name = "피싱 프릭스 - 배스라이즈"
    TargetPattern = "Fishing Freaks - Bass Rise for WonderSwan"
    BasePattern = @(
        "Fishing.*Freaks.*Bass.*Rise.*WonderSwan",
        "Freaks.*Bass.*Fishing.*WonderSwan",
        "WonderSwan.*Bass.*Freaks"
    )
},
@{
    Name = "TV 애니메이션 원피스 - 노려라 해적왕"
    TargetPattern = "From TV Animation One Piece - Mezase Kaizoku Ou!"
    BasePattern = @(
        "TV.*Animation.*One.*Piece.*Mezase.*Kaizoku.*Ou",
        "One.*Piece.*Kaizoku.*TV.*Animation",
        "Kaizoku.*Ou.*Piece.*Animation"
    )
},
@{
    Name = "원조 자자마루군"
    TargetPattern = "Ganso Jajamaru-kun"
    BasePattern = @(
        "Ganso.*Jajamaru.*kun",
        "Jajamaru.*Ganso.*kun",
        "kun.*Jajamaru.*Ganso"
    )
},
@{
    Name = "오락왕 탱고!"
    TargetPattern = "Goraku Ou Tango!"
    BasePattern = @(
        "Goraku.*Ou.*Tango",
        "Ou.*Tango.*Goraku",
        "Tango.*Goraku.*Ou"
    )
},
@{
    Name = "건페이"
    TargetPattern = "GunPey"
    BasePattern = @(
        "GunPey",
        "Gun.*Pey",
        "Pey.*Gun"
    )
},

@{
    Name = "하로보츠"
    TargetPattern = "Harobots"
    BasePattern = @(
        "Harobots",
        "Haro.*bots",
        "bots.*Haro"
    )
},
@{
    Name = "헌터 X 헌터 - 의지를 잇는 자"
    TargetPattern = "Hunter X Hunter - Ishi o Tsugu Mono"
    BasePattern = @(
        "Hunter.*X.*Hunter.*Ishi.*Tsugu.*Mono",
        "X.*Hunter.*Mono.*Tsugu.*Ishi",
        "Mono.*Ishi.*Hunter.*X"
    )
},
@{
    Name = "격투 요리 전설 비스트로 레시피 - 원더 배틀편"
    TargetPattern = "Kakutou Ryouri Densetsu Bistro Recipe - Wonder Battle Hen"
    BasePattern = @(
        "Kakutou.*Ryouri.*Densetsu.*Bistro.*Recipe.*Wonder.*Battle.*Hen",
        "Ryouri.*Bistro.*Battle.*Kakutou.*Hen",
        "Wonder.*Recipe.*Ryouri.*Kakutou"
    )
},
@{
    Name = "바람의 크로노아 - 문라이트 뮤지엄"
    TargetPattern = "Kaze no Klonoa - Moonlight Museum"
    BasePattern = @(
        "Kaze.*no.*Klonoa.*Moonlight.*Museum",
        "Klonoa.*Moonlight.*Museum.*Kaze",
        "Museum.*Kaze.*no.*Klonoa"
    )
},

@{
    Name = "키스부터…- 시사이드 세레나데"
    TargetPattern = "Kiss Yori... - Seaside Serenade"
    BasePattern = @(
        "Kiss.*Yori.*Seaside.*Serenade",
        "Yori.*Seaside.*Kiss.*Serenade",
        "Serenade.*Kiss.*Yori.*Seaside"
    )
},
@{
    Name = "육아 퀴즈 어디서나 - 마이 엔젤"
    TargetPattern = "Kosodate Quiz Dokodemo - My Angel"
    BasePattern = @(
        "Kosodate.*Quiz.*Dokodemo.*My.*Angel",
        "Quiz.*Dokodemo.*Kosodate.*Angel",
        "Angel.*Quiz.*Kosodate.*Dokodemo"
    )
},
@{
    Name = "랑그릿사 밀레니엄 WS - 라스트 센츄리"
    TargetPattern = "Langrisser Millennium WS - The Last Century"
    BasePattern = @(
        "Langrisser.*Millennium.*WS.*Last.*Century",
        "Millennium.*Last.*Langrisser.*Century",
        "Century.*Langrisser.*Millennium.*WS"
    )
},
@{
    Name = "라스트 스탠드"
    TargetPattern = "Last Stand"
    BasePattern = @(
        "Last.*Stand",
        "Stand.*Last"
    )
},
@{
    Name = "로드 러너 원더스완"
    TargetPattern = "Lode Runner for WonderSwan"
    BasePattern = @(
        "Lode.*Runner.*WonderSwan",
        "Runner.*Wonder.*Swan.*Lode",
        "Wonder.*Swan.*Lode.*Runner"
    )
},

@{
    Name = "마크로스 - 트루 러브 송"
    TargetPattern = "Macross - True Love Song"
    BasePattern = @(
        "Macross.*True.*Love.*Song",
        "True.*Love.*Macross.*Song",
        "Song.*Macross.*True.*Love"
    )
},
@{
    Name = "매지컬 드롭 원더스완"
    TargetPattern = "Magical Drop for WonderSwan"
    BasePattern = @(
        "Magical.*Drop.*Wonder.*Swan",
        "Drop.*Magical.*Wonder.*Swan",
        "WonderSwan.*Magical.*Drop"
    )
},
@{
    Name = "마계촌 원더스완"
    TargetPattern = "Makaimura for WonderSwan"
    BasePattern = @(
        "Makaimura.*Wonder.*Swan",
        "Wonder.*Swan.*Makaimura"
    )
},
@{
    Name = "메다롯트 퍼펙트 에디션 - 카부토 버전"
    TargetPattern = "Medarot Perfect Edition - Kabuto Version"
    BasePattern = @(
        "Medarot.*Perfect.*Edition.*Kabuto.*Version",
        "Perfect.*Kabuto.*Medarot.*Version",
        "Kabuto.*Version.*Medarot.*Perfect"
    )
},
@{
    Name = "메다롯트 퍼펙트 에디션 - 쿠와가타 버전"
    TargetPattern = "Medarot Perfect Edition - Kuwagata Version"
    BasePattern = @(
        "Medarot.*Perfect.*Edition.*Kuwagata.*Version",
        "Perfect.*Kuwagata.*Medarot.*Version",
        "Kuwagata.*Version.*Medarot.*Perfect"
    )
},
@{
    Name = "명탐정 코난 - 마술사의 도전장"
    TargetPattern = "Meitantei Conan - Majutsushi no Chousenjou!"
    BasePattern = @(
        "Meitantei.*Conan.*Majutsushi.*Chousenjou",
        "Meitantei.*Conan.*Chousenjou",
        "Meitantei.*Conan.*Majutsushi",
        "Majutsushi.*Meitantei.*Conan",
        "Conan.*Meitantei.*Majutsushi"
    )
},

@{
    Name = "명탐정 코난 - 서쪽 명탐정 최대의 위기"
    TargetPattern = "Meitantei Conan - Nishi no Meitantei Saidai no Kiki!"
    BasePattern = @(
        "Meitantei.*Conan.*Nishi.*Meitantei.*Saidai.*Kiki",
        "Meitantei.*Conan.*Nishi",
        "Conan.*Meitantei.*Nishi"
    )
},

@{
    Name = "밍글 마그넷"
    TargetPattern = "Mingle Magnet"
    BasePattern = @(
        "Mingle.*Magnet"
    )
},

@{
    Name = "기동전사 건담 MSVS"
    TargetPattern = "Mobile Suit Gundam MSVS"
    BasePattern = @(
        "Mobile.*Suit.*Gundam.*MSVS"
    )
},

@{
    Name = "불타라!! 프로 야구 루키"
    TargetPattern = "Moero!! Pro Yakyuu Rookies"
    BasePattern = @(
        "Moero!!.*Pro.*Yakyuu.*Rookies"
    )
},

@{
    Name = "수수께끼 왕 포켓"
    TargetPattern = "Nazo Ou Pocket"
    BasePattern = @(
        "Nazo.*Ou.*Pocket"
    )
},

@{
    Name = "신세기 에반게리온 - 사도육성"
    TargetPattern = "Neon Genesis Evangelion - Shito Ikusei"
    BasePattern = @(
        "Neon.*Genesis.*Evangelion.*Shito.*Ikusei",
        "Neon.*Genesis.*Evangelion.*Shito",
        "Evangelion.*Neon.*Genesis.*Shito"
    )
},

@{
    Name = "나이스 온"
    TargetPattern = "Nice On"
    BasePattern = @(
        "Nice.*On"
    )
},

@{
    Name = "노부나가의 야망 원더스완"
    TargetPattern = "Nobunaga no Yabou for WonderSwan"
    BasePattern = @(
        "Nobunaga.*Yabou.*Wonder.*Swan",
        "Nobunaga.*Yabou",
        "Yabou.*Nobunaga"
    )
},

@{
    Name = "오짱의 오에카키 로직"
    TargetPattern = "Ou-chan no Oekaki Logic"
    BasePattern = @(
        "Ou-chan.*Oekaki.*Logic"
    )
},

@{
    Name = "포켓 파이터"
    TargetPattern = "Pocket Fighter"
    BasePattern = @(
        "Pocket.*Fighter"
    )
},

@{
    Name = "뿌요 뿌요 2"
    TargetPattern = "Puyo Puyo Tsuu"
    BasePattern = @(
        "Puyo.*Puyo.*Tsuu",
        "Puyo.*Puyo.*2"
    )
},

@{
    Name = "퍼즐 보블 / 버스트 어 무브"
    TargetPattern = "Puzzle Bobble"
    BasePattern = @(
        "Puzzle.*Bobble",
        "Bust.*Move"
    )
},

@{
    Name = "레인보우 아일랜드 - 퍼티 파티"
    TargetPattern = "Rainbow Islands - Putty's Party"
    BasePattern = @(
        "Rainbow.*Islands.*Putty.*Party",
        "Rainbow.*Islands",
        "Islands.*Rainbow"
    )
},

@{
    Name = "링 인피니티"
    TargetPattern = "Ring Infinity"
    BasePattern = @(
        "Ring.*Infinity"
    )
},
@{
    Name = "록맨 & 포르테 - 미래로부터의 도전자"
    TargetPattern = "Rockman & Forte - Mirai Kara no Chousensha"
    BasePattern = @(
        "Rockman.*Forte.*Mirai.*Kara.*Chousensha",
        "Rockman.*Forte",
        "Forte.*Rockman"
    )
},


@{
    Name = "삼국지 2 원더스완"
    TargetPattern = "Sangokushi II for WonderSwan"
    BasePattern = @(
        "Sangokushi.*II.*Wonder.*Swan",
        "Sangokushi.*2.*Wonder.*Swan",
        "Sangokushi.*2",
        "Sangokushi.*II"
    )
},

@{
    Name = "삼국지 원더스완"
    TargetPattern = "Sangokushi for WonderSwan"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*Sangokushi.*Wonder.*Swan",
        "^(?!.*(?:2|3|II|III)).*Sangokushi"
    )
},

@{
    Name = "SD 건담 - 이모셔널 잼"
    TargetPattern = "SD Gundam - Emotional Jam"
    BasePattern = @(
        "SD.*Gundam.*Emotional.*Jam",
        "SD.*Gundam.*Emotional",
        "SD.*Gundam.*Jam"
    )
},

@{
    Name = "SD 건담 G 제너레이션 - 게더 비트"
    TargetPattern = "SD Gundam G Generation - Gather Beat"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*SD.*Gundam.*G.*Generation.*Gather.*Beat",
        "^(?!.*(?:2|3|II|III)).*SD.*Gundam.*G.*Generation",
        "^(?!.*(?:2|3|II|III)).*SD.*Gundam.*G.*Beat"
    )
},

@{
    Name = "SD 건담 가샤폰 전기 - 에피소드 1"
    TargetPattern = "SD Gundam Gashapon Senki - Episode 1"
    BasePattern = @(
        "^(?!.*(?:2|3|II|III)).*SD.*Gundam.*Gashapon.*Senki.*Episode.*1",
        "^(?!.*(?:2|3|II|III)).*SD.*Gundam.*Gashapon.*Episode.*1",
        "^(?!.*(?:2|3|II|III)).*Gashapon.*Gundam.*Episode.*1"
    )
},

@{
    Name = "선계전 - TV 애니메이션 신계전 봉신연희"
    TargetPattern = "Senkaiden - TV Animation Senkaiden Houshin Engi Yori"
    BasePattern = @(
        "Senkaiden.*TV.*Animation.*Senkaiden.*Houshin.*Engi.*Yori",
        "Senkaiden.*Houshin.*Engi.*Yori",
        "Senkaiden.*Houshin"
    )
},

@{
    Name = "천년 밀레니엄"
    TargetPattern = "Sennou Millennium"
    BasePattern = @(
        "Sennou.*Millennium"
    )
},

@{
    Name = "신 일본 프로레슬링 - 투혼 열전"
    TargetPattern = "Shin Nihon Pro Wrestling - Toukon Retsuden"
    BasePattern = @(
        "Shin.*Nihon.*Pro.*Wrestling.*Toukon.*Retsuden",
        "Shin.*Nihon.*Pro.*Wrestling",
        "Pro.*Wrestling.*Shin.*Nihon"
    )
},

@{
    Name = "사커 하자! - 챌린지 더 월드"
    TargetPattern = "Soccer Yarou! - Challenge the World"
    BasePattern = @(
        "Soccer.*Yarou.*Challenge.*World",
        "Soccer.*Yarou",
        "Yarou.*Soccer"
    )
},
@{
    Name = "졸업"
    TargetPattern = "Sotsugyou for WonderSwan"
    BasePattern = @(
        "Sotsugyou.*Wonder.*Swan",
        "Sotsugyou"
    )
},

@{
    Name = "스페이스 인베이더"
    TargetPattern = "Space Invaders"
    BasePattern = @(
        "Space.*Invader"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트 2 - 제1부 - 지상 격동편"
    TargetPattern = "Super Robot Taisen Compact 2 - Dai-1-bu - Chijou Gekidou Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*1.*bu.*Chijou.*Gekidou.*Hen",
        "Super.*Robot.*Taisen.*Compact.*2.*Chijou",
        "Super.*Robot.*Taisen.*2.*Dai.*1.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*1.*bu"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트 2 - 제2부 - 우주 격진편"
    TargetPattern = "Super Robot Taisen Compact 2 - Dai-2-bu - Uchuu Gekishin Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*2.*bu.*Uchuu.*Gekishin.*Hen",
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*2.*Gekishin.*Hen",
        "Super.*Robot.*Taisen.*2.*Dai.*2.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*2.*bu"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트 2 - 제3부 - 은하 결전편"
    TargetPattern = "Super Robot Taisen Compact 2 - Dai-3-bu - Ginga Kessen Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*3.*bu.*Ginga.*Kessen.*Hen",
        "Super.*Robot.*Taisen.*Compact.*2.*Ginga.*Kessen.*Hen",
        "Super.*Robot.*Taisen.*2.*Dai.*3.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*3.*bu"
    )
},

@{
    Name = "슈퍼 로봇 대전 콤팩트"
    TargetPattern = "Super Robot Taisen Compact"
    BasePattern = @(
        "^(?!.*(?:(?<!\((rev|ver)\s+)(?:2|3|II|III|color))).*Super.*Robot.*Taisen.*Compact.*\((rev|ver)\s+\d+\)",
        "^(?!.*(?:2|3|II|III|color)).*Super.*Robot.*Taisen.*Compact"
    )
},

@{
    Name = "탄생 데뷰"
    TargetPattern = "Tanjou Debut for WonderSwan"
    BasePattern = @(
        "Tanjou.*Debut.*Wonder.*Swan",
        "Tanjou.*Debut"
    )
},

@{
    Name = "타레팬더의 군페이"
    TargetPattern = "Tare Panda no GunPey"
    BasePattern = @(
        "Tare.*Panda.*GunPey"
    )
},

@{
    Name = "철권 카드 챌린지"
    TargetPattern = "Tekken Card Challenge"
    BasePattern = @(
        "Tekken.*Card.*Challenge"
    )
},

@{
    Name = "테러"
    TargetPattern = "Terrors"
    BasePattern = @(
        "Terror"
    )
},
@{
    Name = "철인 28호"
    TargetPattern = "Tetsujin 28 Gou"
    BasePattern = @(
        "Tetsujin.*28.*Gou",
        "Tetsujin.*28",
        "28.*Gou.*Tetsujin"
    )
},

@{
    Name = "타임 보칸 시리즈 - 보칸전설"
    TargetPattern = "Time Bokan Series - Bokan Densetsu - Buta mo Odaterya Doronboo"
    BasePattern = @(
        "Time.*Bokan.*Series.*Bokan.*Densetsu.*Buta.*Odaterya.*Doronboo",
        "Time.*Bokan.*Series",
        "Bokan.*Densetsu"
    )
},

@{
    Name = "도쿄 마인 학원 - 부주봉록"
    TargetPattern = "Tokyo Majin Gakuen - Fuju Houroku"
    BasePattern = @(
        "Tokyo.*Majin.*Gakuen.*Fuju.*Houroku",
        "Tokyo.*Majin.*Gakuen",
        "Majin.*Gakuen"
    )
},

@{
    Name = "턴테이블리스트 - DJ 배틀"
    TargetPattern = "Turntablist - DJ Battle"
    BasePattern = @(
        "Turn.*tablist.*DJ.*Battle"
    )
},

@{
    Name = "바다낚시 가자!"
    TargetPattern = "Umizuri ni Ikou!"
    BasePattern = @(
        "Umizuri.*Ikou"
    )
},

@{
    Name = "소용돌이 - 전시괴기편"
    TargetPattern = "Uzumaki - Denshi Kaiki Hen"
    BasePattern = @(
        "Uzumaki.*Denshi.*Kaiki.*Hen",
        "Uzumaki.*Denshi",
        "Denshi.*Kaiki"
    )
},

@{
    Name = "소용돌이 - 저주 시뮬레이션"
    TargetPattern = "Uzumaki - Noroi Simulation"
    BasePattern = @(
        "Uzumaki.*Noroi.*Simulation",
        "Uzumaki.*Noroi",
        "Noroi.*Simulation"
    )
},

@{
    Name = "바이츠 블레이드"
    TargetPattern = "Vaitz Blade"
    BasePattern = @(
        "Vaitz.*Blade"
    )
},

@{
    Name = "와사비 프로듀스 - 스트리트 댄서"
    TargetPattern = "Wasabi Produce - Street Dancer"
    BasePattern = @(
        "Wasabi.*Produce.*Street.*Dancer",
        "Wasabi.*Produce",
        "Produce.*Street"
    )
},
@{
    Name = "원더 스타디움 99"
    TargetPattern = "Wonder Stadium '99"
    BasePattern = @(
        "Wonder.*Stadium.*'99",
        "Wonder.*Stadium"
    )
},

@{
    Name = "원더 스타디움"
    TargetPattern = "Wonder Stadium"
    BasePattern = @(
        "^(?!.*(?:99|9|96)).*Wonder.*Stadium"
    )
},

@{
    Name = "원더스완 핸디 소나"
    TargetPattern = "WonderSwan Handy Sonar"
    BasePattern = @(
        "Wonder.*Swan.*Handy.*Sonar",
        "Handy.*Sonar"
    )
}



)

# best 폴더가 없으면 생성
if (-not (Test-Path "best")) {
    New-Item -ItemType Directory -Path "best"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./best/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # USA 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\best\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외    
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -match '\(.*USA.*?\)' -or $file.Name -match '\[.*USA.*?\]')
                  }

    # USA 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\best\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                      ($file.Name -notmatch "(?i)beta|demo|sample") -and  # beta와 demo 제외    
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to best folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")