﻿[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 게임 목록
$games = @(



@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트 2 - 제1부 - 지상 격동편"
    TargetPattern = "(K) Super Robot Taisen Compact 2 - Dai-1-bu - Chijou Gekidou Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*1.*bu.*Chijou.*Gekidou.*Hen",
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*1.*bu",
        "슈퍼.*로봇.*대전.*2.*1.*지상.*격동",
        "슈퍼.*로봇.*대전.*2.*1",
        "슈퍼.*로봇.*대전.*2.*지상.*격동",
        "로봇.*대전.*2.*지상.*격동",
        "슈로대.*1.*지상.*격동"
        "Super.*Robot.*Taisen.*Compact.*2.*Chijou",
        "Super.*Robot.*Taisen.*2.*Dai.*1.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*1.*bu"
    )
},

@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트 2 - 제2부 - 우주 격진편"
    TargetPattern = "(K) Super Robot Taisen Compact 2 - Dai-2-bu - Uchuu Gekishin Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*2.*bu.*Uchuu.*Gekishin.*Hen",
        "슈퍼.*로봇.*대전.*2.*2.*우주.*격진",
        "슈퍼.*로봇.*대전.*2.*2",
        "슈퍼.*로봇.*대전.*우주.*격진",
        "슈로대.*2.*2.*우주.*격진"
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*2.*Gekishin.*Hen",
        "Super.*Robot.*Taisen.*2.*Dai.*2.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*2.*bu"
    )
},

@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트 2 - 제3부 - 은하 결전편"
    TargetPattern = "(K) Super Robot Taisen Compact 2 - Dai-3-bu - Ginga Kessen Hen"
    BasePattern = @(
        "Super.*Robot.*Taisen.*Compact.*2.*Dai.*3.*bu.*Ginga.*Kessen.*Hen",
        "슈퍼.*로봇.*대전.*2.*3.*은하.*결전",
        "슈퍼.*로봇.*대전.*2.*3",
        "로봇.*은하.*결전",
        "슈로대.*은하.*결전",
        "3.*은하.*결전"
        "Super.*Robot.*Taisen.*Compact.*2.*Ginga.*Kessen.*Hen",
        "Super.*Robot.*Taisen.*2.*Dai.*3.*bu",
        "Robot.*Taisen.*Compact.*2.*Dai.*3.*bu"
    )
},

@{
    Name = "(K) 슈퍼 로봇 대전 콤팩트"
    TargetPattern = "(K) Super Robot Taisen Compact"
    BasePattern = @(
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*Super.*Robot.*Taisen.*Compact",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈퍼.*로봇.*대전.*콤팩트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈퍼.*로봇.*대전.*콤펙트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈퍼.*로봇.*대전.*컴팩트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈퍼.*로봇.*대전.*컴펙트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈퍼.*로봇.*대전.*Compact",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈로대.*콤.*트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*슈로대.*컴.*트",
        "^(?!.*(?:(?<!\([^)]*?)(?:2|3|II|III|dai|color))).*Super.*Robot.*Taisen.*Compact"
    )
}


)

# patched 폴더가 없으면 생성
if (-not (Test-Path "patched")) {
    New-Item -ItemType Directory -Path "patched"
}

# 각 게임 처리
foreach ($game in $games) {
    Write-Host ('Processing: ' + $game.Name)

# 먼저 이미 처리된 파일이 있는지 확인
$zipFilePath = "./patched/" + $game.TargetPattern + ".zip"
if (Test-Path $zipFilePath) {
    Write-Host ('Skipping: ' + $game.Name + ' (File already exists)')
    Write-Host '------------------------'
    continue
}

    # Kor 버전 먼저 찾기 (zip 파일만 매칭)
    $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                  Where-Object { 
                      $file = $_
                      $file.FullName -notlike "*\patched\*" -and
                      ($file.Extension -match "(?i)\.zip") -and
                      ($game.BasePattern | Where-Object { $file.Name -match $_ }) -and 
                      ($file.Name -match '\(.*Kor.*?\)' -or $file.Name -match '\[.*Kor.*?\]')
                  }

    # Kor 버전이 없으면 다른 버전 찾기 (zip 파일만 매칭)
    if (-not $foundFiles) {
        $foundFiles = Get-ChildItem -File -Recurse -ErrorAction SilentlyContinue | 
                     Where-Object { 
                         $file = $_
                         $file.FullName -notlike "*\patched\*" -and
                         ($file.Extension -match "(?i)\.zip") -and
                         ($game.BasePattern | Where-Object { $file.Name -match $_ })
                     }
    }

    if ($foundFiles -and @($foundFiles).Count -gt 0) {
        try {
            # 첫 번째 파일만 선택
            $selectedFile = @($foundFiles)[0]
            
            Write-Host ('Selected file for processing: ' + $selectedFile.Name)
            
            # 직접 파일 복사
            Copy-Item -LiteralPath $selectedFile.FullName -Destination $zipFilePath -Force
            Write-Host ('Copied to patched folder: ' + $zipFilePath)
        }
        catch {
            Write-Host ('Error occurred: ' + $_.Exception.Message)
        }
    } else {
        Write-Host ('File not found for pattern: ' + $game.TargetPattern)
    }

    Write-Host '------------------------'
}

Write-Host "All processing completed. Press any key to exit..."
$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")